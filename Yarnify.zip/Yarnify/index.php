<?php
require_once 'config/db.php';

// Fetch trending products
$trending_query = "SELECT * FROM products WHERE is_trending = 1 LIMIT 8";
$trending_result = $conn->query($trending_query) or die($conn->error);

// Fetch bestseller products
$bestseller_query = "SELECT * FROM products WHERE is_bestseller = 1 LIMIT 8";
$bestseller_result = $conn->query($bestseller_query) or die($conn->error);

// Fetch new arrivals
$new_arrivals_query = "SELECT * FROM products ORDER BY created_at DESC LIMIT 8";
$new_arrivals_result = $conn->query($new_arrivals_query) or die($conn->error);

// Close the database connection after all operations
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Explore YARNIFY's handcrafted crochet collection. Luxury, customizable, and made with love.">
    <meta name="keywords" content="crochet, handmade, luxury, accessories, bags, tops, plushies">
    <title>YARNIFY - Handmade with Love 💖</title>
    <link rel="stylesheet" href="style.css">
    <style>
        :root {
            --deep-rose: #D85D7A;
            --soft-pink: #FFE4E9;
            --light-pink: #FFF0F5;
        }

        /* Your existing CSS */
        .hero-section {
            position: relative;
            text-align: center;
            padding: 100px 20px 140px;
            background: radial-gradient(circle at center, #fff6f8 0%, #ffe4ec 60%, #ffd9e6 100%);
            overflow: hidden;
        }
        .hero-background-text {
            position: absolute;
            top: 48%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 110px;
            font-weight: 700;
            color: rgba(176, 48, 82, 0.05);
            letter-spacing: 8px;
            white-space: nowrap;
            z-index: 0;
        }
        .hero-content {
            position: relative;
            z-index: 2;
        }
        .hero-logo-wrapper {
            width: 300px;
            height: 300px;
            margin: 0 auto 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(145deg, #fff0f5, #ffe4ec);
            box-shadow: 0 20px 60px rgba(216, 93, 122, 0.25), inset 0 0 40px rgba(255, 255, 255, 0.6);
            transform: translateY(-85px);
        }
        .hero-logo {
            width: 85%;
            height: 85%;
            object-fit: contain;
            border-radius: 50%;
        }
        .hero-title {
            font-size: 42px;
            color: #8B2E4A;
            margin-top: -10px;
        }
        .hero-subtitle {
            font-size: 18px;
            color: #A0526D;
            margin: 15px 0 30px;
        }
        .btn-primary {
            background-color: #D85D7A;
            color: white;
            padding: 12px 32px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #B03052;
        }
        .btn-secondary {
            background-color: #F8C8D8;
            color: #8B2E4A;
            padding: 12px 32px;
            border: none;
            border-radius: 30px;
            margin-left: 15px;
            cursor: pointer;
            transition: 0.3s ease;
        }
        .btn-secondary:hover {
            background-color: #F4A6B5;
        }

        /* Footer positioning and responsiveness */
        .footer {
            margin-top: 80px;
            padding: 3rem 2rem 2rem;
            background: var(--gradient-pink);
            width: 100%;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 40px;
        }

        .footer-section {
            display: flex;
            flex-direction: column;
        }

        .footer-section h3 {
            color: #8B2E4A;
            margin-bottom: 20px;
            font-size: 1.2rem;
        }

        .footer-section p {
            color: #666;
            line-height: 1.5;
            margin-bottom: 1rem;
        }

        .footer-section a {
            color: #A0526D;
            text-decoration: none;
            margin-bottom: 10px;
            transition: color 0.3s ease;
        }

        .footer-section a:hover {
            color: #D85D7A;
        }

        .social-links {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }

        .social-icon {
            color: #8B2E4A;
            transition: color 0.3s;
        }

        .social-icon:hover {
            color: #D85D7A;
        }

        .footer-bottom {
            margin-top: 60px;
            padding: 30px 0;
            text-align: center;
            border-top: 1px solid rgba(176, 48, 82, 0.1);
            color: #8B2E4A;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .footer-content {
                grid-template-columns: repeat(2, 1fr);
                gap: 30px;
            }

            .hero-background-text {
                font-size: 90px;
            }

            .product-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 768px) {
            .footer-content {
                grid-template-columns: 1fr;
                gap: 40px;
            }

            .hero-section {
                padding: 80px 20px 100px;
            }

            .hero-background-text {
                font-size: 60px;
                top: 45%;
            }

            .hero-logo-wrapper {
                width: 250px;
                height: 250px;
                transform: translateY(-60px);
            }

            .hero-title {
                font-size: 32px;
            }

            .hero-subtitle {
                font-size: 16px;
                padding: 0 20px;
            }

            .product-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .tabs-container {
                overflow-x: auto;
                white-space: nowrap;
                padding-bottom: 10px;
            }

            .tab-btn {
                font-size: 14px;
                padding: 8px 16px;
            }

            .nav-left, .nav-right {
                position: fixed;
                top: 80px;
                left: 0;
                width: 100%;
                background: white;
                padding: 1rem;
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .nav-left.active, .nav-right.active {
                transform: translateX(0);
            }
        }

        @media (max-width: 480px) {
            .footer-content {
                padding: 0 15px;
            }

            .footer-section {
                text-align: center;
            }

            .hero-logo-wrapper {
                width: 200px;
                height: 200px;
                transform: translateY(-40px);
            }

            .hero-background-text {
                font-size: 40px;
                letter-spacing: 4px;
            }

            .hero-title {
                font-size: 28px;
            }

            .hero-subtitle {
                font-size: 14px;
            }

            .hero-buttons {
                display: flex;
                flex-direction: column;
                gap: 15px;
                align-items: center;
            }

            .btn-secondary {
                margin-left: 0;
            }

            .product-grid {
                grid-template-columns: 1fr;
                padding: 0 10px;
            }

            .product-card {
                max-width: 100%;
            }

            .section-title {
                font-size: 1.8rem;
            }

            .whatsapp-float {
                width: 50px;
                height: 50px;
                bottom: 20px;
                right: 15px;
            }
        }

        /* Ensure product grid is responsive */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        /* Responsive wave dividers */
        .wave-divider svg {
            width: 100%;
            height: auto;
            display: block;
        }

        /* Responsive tab buttons */
        .tabs-container {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 40px;
        }

        /* Ensure images are responsive */
        .product-image {
            width: 100%;
            height: auto;
            aspect-ratio: 1/1;
            object-fit: cover;
        }

        /* Responsive hero buttons */
        .hero-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        html, body {
            height: 100%;
        }

        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
        }
    </style>
    <link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <!-- Splash Screen -->
    <div class="splash-screen">
        <svg class="crochet-heart" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M50 85C50 85 15 65 15 40C15 20 30 15 40 25C45 30 50 35 50 35C50 35 55 30 60 25C70 15 85 20 85 40C85 65 50 85 50 85Z"
                  fill="#D85D7A" stroke="#FFB3C1" stroke-width="2">
                <animate attributeName="fill" values="#D85D7A;#FFB3C1;#D85D7A" dur="2s" repeatCount="indefinite"/>
            </path>
        </svg>
        <div class="splash-logo">YARNIFY</div>
        <div class="splash-loader"></div>
    </div>

    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>
        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>
        <div class="nav-right">
            <div class="search-container">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="11" cy="11" r="8"/>
                    <path d="M21 21l-4.35-4.35"/>
                </svg>
            </div>
           <a href="<?php echo isset($_SESSION['user_id']) ? 'wishlist.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <span class="wishlist-count" style="display: none;">0</span>
            </a>
            <a href="cart.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
                <span class="cart-count" style="display: none;">0</span>
            </a>
            <a href="<?php echo isset($_SESSION['user_id']) ? 'profile.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
        <div class="menu-toggle">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

<main>
    <!-- Hero Section -->
    <section class="hero-section">
        <h1 class="hero-background-text">HANDMADE LOVE</h1>
        <div class="hero-content">
            <div class="hero-logo-wrapper">
                <img src="assets/images/Yarnify_logo-fotor-20260207203218.svg" alt="Yarnify Logo" class="hero-logo">
            </div>
            <h1 class="hero-title">Handcrafted with Love</h1>
            <p class="hero-subtitle">Explore our collection of luxury crochet pieces, made just for you</p>
            <div class="hero-buttons">
                <a href="shop.php"><button class="btn-primary">Shop Now</button></a>
                <a href="collections.php"><button class="btn-secondary">Explore Collection</button></a>
            </div>
        </div>
    </section>

    <!-- Wave Divider -->
    <div class="wave-divider">
        <svg viewBox="0 0 1200 100" preserveAspectRatio="none">
            <path d="M0,50 C300,100 900,0 1200,50 L1200,100 L0,100 Z" fill="#FFFFFF"/>
        </svg>
    </div>

    <!-- Trending Products -->
    <section class="section" style="background: white;">
        <h2 class="section-title reveal">Trending Now 🌸</h2>
        <div class="product-grid">
            <?php while ($product = $trending_result->fetch_assoc()): ?>
            <div class="product-card reveal">
                <span class="product-badge">Trending</span>
                <div class="product-image-container">
                    <img src="assets/images/products/<?php echo !empty($product['image']) ? htmlspecialchars($product['image']) : 'placeholder.jpg'; ?>"
                         alt="<?php echo htmlspecialchars($product['name']); ?>"
                         class="product-image"
                         loading="lazy">
                </div>
                <div class="product-info">
                    <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p class="product-price">₹<?php echo number_format($product['price'], 2); ?></p>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="addToCart(<?php echo $product['id']; ?>)">Add to Cart</button>
                        <button class="wishlist-btn" onclick="addToWishlist(<?php echo $product['id']; ?>)">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>

    <!-- Wave Divider -->
    <div class="wave-divider">
        <svg viewBox="0 0 1200 100" preserveAspectRatio="none">
            <path d="M0,50 C300,0 900,100 1200,50 L1200,100 L0,100 Z" fill="#FFF5F7"/>
        </svg>
    </div>

    <!-- New Arrivals with Tabs -->
    <section class="section">
        <h2 class="section-title reveal">New Arrivals 💫</h2>
        <div class="tabs-container reveal">
            <button class="tab-btn active" data-tab="all">All</button>
            <button class="tab-btn" data-tab="bags">Bags</button>
            <button class="tab-btn" data-tab="tops">Tops</button>
            <button class="tab-btn" data-tab="accessories">Accessories</button>
            <button class="tab-btn" data-tab="plushies">Plushies</button>
        </div>
        <div class="product-grid tab-content active" id="all">
            <?php
            $new_arrivals_result->data_seek(0);
            while ($product = $new_arrivals_result->fetch_assoc()):
            ?>
            <div class="product-card reveal">
                <?php if ($product['is_bestseller']): ?>
                <span class="product-badge">Best Seller</span>
                <?php endif; ?>
                <div class="product-image-container">
                    <img src="assets/images/products/<?php echo !empty($product['image']) ? htmlspecialchars($product['image']) : 'placeholder.jpg'; ?>"
                         alt="<?php echo htmlspecialchars($product['name']); ?>"
                         class="product-image"
                         loading="lazy">
                </div>
                <div class="product-info">
                    <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p class="product-price">$<?php echo number_format($product['price'], 2); ?></p>
                    <div class="product-actions">
                        <button class="add-to-cart-btn" onclick="addToCart(<?php echo $product['id']; ?>)">Add to Cart</button>
                        <button class="wishlist-btn" onclick="addToWishlist(<?php echo $product['id']; ?>)">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </section>
</main>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care. Each item is unique and crafted to bring joy to your life.</p>
                <p>Yarnify is a handmade crochet brand offering affordable and customizable accessories crafted with love.</p>
                <div class="social-links">
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-9-9 9 9 0 0 1 9-9c2.5 0 4.8.9 6.5 2.4"/>
                            <path d="M16 8h-2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v-4h-1"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <path d="M22 6l-10 7L2 6"/>
                        </svg>
                    </a>
                </div>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="shop.php">Shop</a>
                <a href="collections.php">Collections</a>
                <a href="about.php">About</a>
                <a href="reviews.php">Reviews</a>
            </div>
            <div class="footer-section">
                <h3>Customer Care</h3>
                <a href="#">Shipping Info</a>
                <a href="#">Returns</a>
                <a href="#">FAQ</a>
                <a href="#">Contact Us</a>
            </div>
            <div class="footer-section">
                <h3>Newsletter</h3>
                <p>Subscribe for exclusive offers and updates!</p>
                <form style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                    <input type="email" placeholder="Your email" style="flex: 1; padding: 0.8rem; border-radius: 25px; border: none;">
                    <button type="submit" class="btn-primary" style="padding: 0.8rem 1.5rem;">Join</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 YARNIFY. Made with 💖 | All Rights Reserved</p>
        </div>
    </footer>

    <!-- Floating WhatsApp -->
    <a href="https://wa.me/8291387452" class="whatsapp-float" target="_blank">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="white">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
    </a>

    <script src="main.js"></script>
    <script>
        // Mobile menu toggle
        document.querySelector('.menu-toggle').addEventListener('click', function() {
            document.querySelector('.nav-left').classList.toggle('active');
            document.querySelector('.nav-right').classList.toggle('active');
        });

        // Scroll animations
        function revealOnScroll() {
            const reveals = document.querySelectorAll('.reveal');
            reveals.forEach(reveal => {
                const windowHeight = window.innerHeight;
                const revealTop = reveal.getBoundingClientRect().top;
                if (revealTop < windowHeight - 150) {
                    reveal.classList.add('active');
                }
            });
        }
        window.addEventListener('scroll', revealOnScroll);
        window.addEventListener('load', revealOnScroll);

        // Tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                this.classList.add('active');
                document.getElementById(this.dataset.tab).classList.add('active');
            });
        });

        // Splash screen
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                document.querySelector('.splash-screen').style.opacity = '0';
                setTimeout(() => {
                    document.querySelector('.splash-screen').style.display = 'none';
                }, 1000);
            }, 2000);
        });

        // Placeholder functions for addToCart and addToWishlist
        function addToCart(productId) {
            console.log("Added to cart:", productId);
        }

        function addToWishlist(productId) {
            console.log("Added to wishlist:", productId);
        }
    </script>
</body>
</html>
