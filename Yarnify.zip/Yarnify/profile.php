<?php
require_once 'config/db.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request';
    } else {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'update_profile') {
            $name = sanitize($_POST['name'] ?? '');
            $phone = sanitize($_POST['phone'] ?? '');
            
            if ($name) {
                $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
                $stmt->bind_param("ssi", $name, $phone, $user_id);
                
                if ($stmt->execute()) {
                    $_SESSION['user_name'] = $name;
                    $success = 'Profile updated successfully!';
                } else {
                    $error = 'Failed to update profile';
                }
                $stmt->close();
            }
        } elseif ($action === 'change_password') {
            $current_password = $_POST['current_password'] ?? '';
            $new_password = $_POST['new_password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            if ($new_password !== $confirm_password) {
                $error = 'New passwords do not match';
            } elseif (strlen($new_password) < 6) {
                $error = 'Password must be at least 6 characters';
            } else {
                // Verify current password
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                
                if (password_verify($current_password, $user['password'])) {
                    $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $update_stmt->bind_param("si", $new_hash, $user_id);
                    
                    if ($update_stmt->execute()) {
                        $success = 'Password changed successfully!';
                    } else {
                        $error = 'Failed to change password';
                    }
                    $update_stmt->close();
                } else {
                    $error = 'Current password is incorrect';
                }
                $stmt->close();
            }
        }
    }
}

// Fetch user data
$user_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_assoc();

// Fetch orders
$orders_stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$orders_stmt->bind_param("i", $user_id);
$orders_stmt->execute();
$orders = $orders_stmt->get_result();

// Fetch wishlist count
$wishlist_stmt = $conn->prepare("SELECT COUNT(*) as count FROM wishlist WHERE user_id = ?");
$wishlist_stmt->bind_param("i", $user_id);
$wishlist_stmt->execute();
$wishlist_count = $wishlist_stmt->get_result()->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - YARNIFY</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .profile-container {
            max-width: 1400px;
            margin: 120px auto 3rem;
            padding: 0 5%;
        }
        
        .profile-header {
            background: var(--gradient-pink);
            padding: 3rem;
            border-radius: 30px;
            margin-bottom: 3rem;
            text-align: center;
        }
        
        .profile-header h1 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
        }
        
        .profile-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        
        .stat-card {
            background: white;
            padding: 2rem;
            border-radius: 20px;
            text-align: center;
            box-shadow: var(--shadow-soft);
            transition: all 0.4s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-medium);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--deep-rose);
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: var(--text-light);
        }
        
        .profile-tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        
        .tab-button {
            padding: 1rem 2rem;
            background: white;
            color: var(--text-dark);
            border-radius: 25px;
            font-weight: 600;
            box-shadow: var(--shadow-soft);
            cursor: pointer;
            transition: all 0.4s ease;
        }
        
        .tab-button.active {
            background: var(--deep-rose);
            color: white;
            box-shadow: var(--glow-pink);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .profile-section {
            background: white;
            padding: 3rem;
            border-radius: 30px;
            box-shadow: var(--shadow-soft);
        }
        
        .profile-section h2 {
            font-size: 2rem;
            margin-bottom: 2rem;
            color: var(--deep-rose);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        
        .form-input {
            width: 100%;
            padding: 1rem 1.5rem;
            border: 2px solid var(--soft-pink);
            border-radius: 25px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
        }
        
        .form-input:focus {
            outline: none;
            border-color: var(--deep-rose);
            box-shadow: var(--glow-pink);
        }
        
        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .orders-table thead {
            background: var(--soft-pink);
        }
        
        .orders-table th {
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--deep-rose);
        }
        
        .orders-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--soft-pink);
        }
        
        .orders-table tbody tr:hover {
            background: var(--light-pink);
        }
        
        .status-badge {
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-pending {
            background: #FFF3E0;
            color: #F57C00;
        }
        
        .status-processing {
            background: #E3F2FD;
            color: #1976D2;
        }
        
        .status-shipped {
            background: #F3E5F5;
            color: #7B1FA2;
        }
        
        .status-delivered {
            background: #E8F5E9;
            color: #2E7D32;
        }
        
        .status-cancelled {
            background: #FFEBEE;
            color: #C62828;
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 15px;
            margin-bottom: 1.5rem;
        }
        
        .alert-success {
            background: #E8F5E9;
            color: #2E7D32;
            border: 1px solid #66BB6A;
        }
        
        .alert-error {
            background: #FFE4E9;
            color: #D85D7A;
            border: 1px solid #FFC0CB;
        }
        
        @media (max-width: 768px) {
            .orders-table {
                font-size: 0.9rem;
            }
            
            .orders-table th,
            .orders-table td {
                padding: 0.5rem;
            }
        }
    </style>
<link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>
        
        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>
        
        <div class="nav-right">
            <a href="wishlist.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <span class="wishlist-count" style="display: none;">0</span>
            </a>
            <a href="cart.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
                <span class="cart-count" style="display: none;">0</span>
            </a>
            <a href="profile.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
    </nav>

    <div class="profile-container">
        <div class="profile-header">
            <h1>Welcome, <?php echo htmlspecialchars($user['name']); ?>! 💖</h1>
            <p style="color: var(--text-light); font-size: 1.1rem;">Manage your account and orders</p>
        </div>

        <div class="profile-stats">
            <div class="stat-card">
                <div class="stat-icon">📦</div>
                <div class="stat-value"><?php echo $orders->num_rows; ?></div>
                <div class="stat-label">Total Orders</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">💖</div>
                <div class="stat-value"><?php echo $wishlist_count; ?></div>
                <div class="stat-label">Wishlist Items</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">⭐</div>
                <div class="stat-value">
                    <?php 
                    $reviews_stmt = $conn->prepare("SELECT COUNT(*) as count FROM reviews WHERE user_id = ?");
                    $reviews_stmt->bind_param("i", $user_id);
                    $reviews_stmt->execute();
                    echo $reviews_stmt->get_result()->fetch_assoc()['count'];
                    ?>
                </div>
                <div class="stat-label">Reviews Written</div>
            </div>
        </div>

        <div class="profile-tabs">
            <button class="tab-button active" onclick="switchTab('orders')">My Orders</button>
            <button class="tab-button" onclick="switchTab('profile')">Profile Settings</button>
            <button class="tab-button" onclick="switchTab('password')">Change Password</button>
            <a href="wishlist.php"><button class="tab-button">My Wishlist</button></a>
            <a href="logout.php"><button class="tab-button" style="background: #FFE4E9; color: var(--deep-rose);">Logout</button></a>
        </div>

        <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
        <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Orders Tab -->
        <div class="tab-content active" id="orders-tab">
            <div class="profile-section">
                <h2>Order History</h2>
                
                <?php if ($orders->num_rows > 0): ?>
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $orders->data_seek(0);
                        while ($order = $orders->fetch_assoc()): 
                        ?>
                        <tr>
                            <td>#<?php echo $order['id']; ?></td>
                            <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                            <td style="font-weight: 600; color: var(--deep-rose);">
                                $<?php echo number_format($order['final_amount'], 2); ?>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo $order['status']; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="/order-details.php?id=<?php echo $order['id']; ?>" 
                                   style="color: var(--deep-rose); font-weight: 600;">View Details</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div style="text-align: center; padding: 3rem; color: var(--text-light);">
                    <p style="font-size: 1.2rem; margin-bottom: 1rem;">No orders yet</p>
                    <a href="/shop.php"><button class="btn-primary">Start Shopping</button></a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Profile Tab -->
        <div class="tab-content" id="profile-tab">
            <div class="profile-section">
                <h2>Profile Information</h2>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" class="form-input" 
                               value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" class="form-input" 
                               value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                        <small style="color: var(--text-light);">Email cannot be changed</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" class="form-input" 
                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>
                    
                    <button type="submit" class="btn-primary">Update Profile</button>
                </form>
            </div>
        </div>

        <!-- Password Tab -->
        <div class="tab-content" id="password-tab">
            <div class="profile-section">
                <h2>Change Password</h2>
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="action" value="change_password">
                    
                    <div class="form-group">
                        <label for="current_password">Current Password</label>
                        <input type="password" id="current_password" name="current_password" 
                               class="form-input" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" id="new_password" name="new_password" 
                               class="form-input" required minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" 
                               class="form-input" required>
                    </div>
                    
                    <button type="submit" class="btn-primary">Change Password</button>
                </form>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care.</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="shop.php">Shop</a>
                <a href="collections.php">Collections</a>
                <a href="about.php">About</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 YARNIFY. Made with 💖</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script>
        function switchTab(tabName) {
            // Remove active class from all buttons and contents
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Add active class to selected
            event.target.classList.add('active');
            document.getElementById(tabName + '-tab').classList.add('active');
        }
    </script>
</body>
</html>
