<?php
require_once 'config/db.php';

$product_id = (int)($_GET['id'] ?? 0);

if (!$product_id) {
    header('Location: shop.php');
    exit();
}

// Fetch product details
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    header('Location: shop.php');
    exit();
}

// Fetch reviews
$reviews_stmt = $conn->prepare("SELECT r.*, u.name as user_name FROM reviews r 
                                 JOIN users u ON r.user_id = u.id 
                                 WHERE r.product_id = ? AND r.status = 'approved' 
                                 ORDER BY r.created_at DESC");
$reviews_stmt->bind_param("i", $product_id);
$reviews_stmt->execute();
$reviews = $reviews_stmt->get_result();

// Calculate average rating
$rating_stmt = $conn->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_reviews 
                                FROM reviews WHERE product_id = ? AND status = 'approved'");
$rating_stmt->bind_param("i", $product_id);
$rating_stmt->execute();
$rating_data = $rating_stmt->get_result()->fetch_assoc();
$avg_rating = round($rating_data['avg_rating'] ?? 0, 1);
$total_reviews = $rating_data['total_reviews'] ?? 0;

// Fetch related products (same category)
$related_stmt = $conn->prepare("SELECT * FROM products WHERE category = ? AND id != ? LIMIT 4");
$related_stmt->bind_param("si", $product['category'], $product_id);
$related_stmt->execute();
$related_products = $related_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - YARNIFY</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .product-detail-container {
            max-width: 1400px;
            margin: 120px auto 3rem;
            padding: 0 5%;
        }
        
        .product-detail-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            margin-bottom: 4rem;
        }
        
        .product-gallery {
            position: sticky;
            top: 100px;
            height: fit-content;
        }
        
        .main-image-container {
            width: 100%;
            height: 600px;
            background: white;
            border-radius: 30px;
            overflow: hidden;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-medium);
            position: relative;
        }
        
        .main-product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.4s ease;
        }
        
        .main-image-container:hover .main-product-image {
            transform: scale(1.05);
        }
        
        .product-badges-container {
            position: absolute;
            top: 1.5rem;
            right: 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }
        
        .thumbnail-gallery {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
        }
        
        .thumbnail-image {
            width: 100%;
            height: 120px;
            object-fit: cover;
            border-radius: 15px;
            cursor: pointer;
            border: 3px solid transparent;
            transition: all 0.3s ease;
        }
        
        .thumbnail-image:hover,
        .thumbnail-image.active {
            border-color: var(--deep-rose);
            transform: scale(1.05);
        }
        
        .product-info {
            padding: 2rem 0;
        }
        
        .product-category {
            color: var(--deep-rose);
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9rem;
            letter-spacing: 1px;
            margin-bottom: 1rem;
        }
        
        .product-title {
            font-size: 3rem;
            margin-bottom: 1rem;
            line-height: 1.2;
        }
        
        .rating-container {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .stars {
            display: flex;
            gap: 0.3rem;
        }
        
        .star {
            color: #FFD700;
            font-size: 1.3rem;
        }
        
        .star.empty {
            color: var(--soft-pink);
        }
        
        .rating-text {
            color: var(--text-light);
        }
        
        .product-price-section {
            background: var(--gradient-pink);
            padding: 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
        }
        
        .product-price-large {
            font-size: 3rem;
            font-weight: 700;
            color: var(--deep-rose);
            margin-bottom: 0.5rem;
        }
        
        .stock-status {
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .in-stock {
            color: #2E7D32;
        }
        
        .out-of-stock {
            color: #C62828;
        }
        
        .product-description {
            line-height: 1.8;
            color: var(--text-dark);
            margin-bottom: 2rem;
            font-size: 1.05rem;
        }
        
        .quantity-section {
            margin-bottom: 2rem;
        }
        
        .quantity-section label {
            display: block;
            font-weight: 600;
            margin-bottom: 1rem;
            font-size: 1.1rem;
        }
        
        .quantity-selector-large {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            background: white;
            padding: 1rem;
            border-radius: 25px;
            width: fit-content;
            box-shadow: var(--shadow-soft);
        }
        
        .quantity-btn-large {
            width: 50px;
            height: 50px;
            background: var(--soft-pink);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--deep-rose);
            font-weight: 700;
            font-size: 1.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .quantity-btn-large:hover {
            background: var(--deep-rose);
            color: white;
            transform: scale(1.1);
        }
        
        .quantity-input-large {
            width: 80px;
            text-align: center;
            border: none;
            font-weight: 600;
            font-size: 1.5rem;
            color: var(--deep-rose);
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .btn-add-cart {
            flex: 2;
            padding: 1.5rem;
            background: var(--deep-rose);
            color: white;
            border-radius: 30px;
            font-size: 1.2rem;
            font-weight: 700;
            box-shadow: var(--shadow-medium);
        }
        
        .btn-add-cart:hover {
            box-shadow: var(--glow-pink);
            transform: translateY(-3px);
        }
        
        .btn-wishlist-large {
            flex: 1;
            padding: 1.5rem;
            background: white;
            color: var(--deep-rose);
            border: 2px solid var(--deep-rose);
            border-radius: 30px;
            font-size: 1.2rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-wishlist-large:hover {
            background: var(--deep-rose);
            color: white;
        }
        
        .product-features {
            background: white;
            padding: 2rem;
            border-radius: 20px;
            box-shadow: var(--shadow-soft);
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 1px solid var(--soft-pink);
        }
        
        .feature-item:last-child {
            border-bottom: none;
        }
        
        .feature-icon {
            font-size: 1.5rem;
        }
        
        /* Reviews Section */
        .reviews-section {
            margin-top: 4rem;
            background: white;
            padding: 3rem;
            border-radius: 30px;
            box-shadow: var(--shadow-soft);
        }
        
        .reviews-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        
        .reviews-header h2 {
            font-size: 2.5rem;
        }
        
        .review-card {
            padding: 2rem;
            background: var(--light-pink);
            border-radius: 20px;
            margin-bottom: 1.5rem;
        }
        
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .reviewer-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .reviewer-avatar {
            width: 50px;
            height: 50px;
            background: var(--gradient-pink);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.2rem;
            color: var(--deep-rose);
        }
        
        .review-date {
            color: var(--text-light);
            font-size: 0.9rem;
        }
        
        .review-comment {
            line-height: 1.6;
            color: var(--text-dark);
        }
        
        /* Add Review Form */
        .add-review-form {
            background: var(--soft-pink);
            padding: 2rem;
            border-radius: 20px;
            margin-top: 2rem;
        }
        
        .add-review-form h3 {
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
        }
        
        .rating-input {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }
        
        .star-input {
            font-size: 2rem;
            cursor: pointer;
            color: var(--soft-pink);
            transition: all 0.3s ease;
        }
        
        .star-input:hover,
        .star-input.selected {
            color: #FFD700;
            transform: scale(1.2);
        }
        
        .form-textarea {
            width: 100%;
            padding: 1rem 1.5rem;
            border: 2px solid white;
            border-radius: 20px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            resize: vertical;
            min-height: 120px;
        }
        
        /* Related Products */
        .related-products {
            margin-top: 4rem;
        }
        
        @media (max-width: 968px) {
            .product-detail-grid {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
            
            .product-gallery {
                position: relative;
                top: 0;
            }
            
            .main-image-container {
                height: 400px;
            }
            
            .product-title {
                font-size: 2rem;
            }
        }
    </style>
<link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>
        
        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>
        
        <div class="nav-right">
            <a href="wishlist.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <span class="wishlist-count" style="display: none;">0</span>
            </a>
            <a href="cart.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
                <span class="cart-count" style="display: none;">0</span>
            </a>
            <a href="<?php echo isLoggedIn() ? '/profile.php' : '/login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
        
        <div class="menu-toggle">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

    <!-- Product Detail -->
    <div class="product-detail-container">
        <div class="product-detail-grid">
            <!-- Product Gallery -->
            <div class="product-gallery">
                <div class="main-image-container">
                    <img src="assets/images/products/<?php echo $product['image']; ?>"
                         alt="<?php echo htmlspecialchars($product['name']); ?>" 
                         class="main-product-image">
                    
                    <div class="product-badges-container">
                        <?php if ($product['is_trending']): ?>
                        <span class="product-badge">Trending</span>
                        <?php endif; ?>
                        
                        <?php if ($product['is_bestseller']): ?>
                        <span class="product-badge" style="background: #FFD700; color: #333;">Best Seller</span>
                        <?php endif; ?>
                        
                        <?php if ($product['stock'] > 0 && $product['stock'] < 5): ?>
                        <span class="product-badge" style="background: #FF6B6B;">Only <?php echo $product['stock']; ?> Left!</span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="thumbnail-gallery">
                    <img src="assets/images/products/<?php echo $product['image']; ?>"
                         alt="View 1" class="thumbnail-image active">
                    <img src="assets/images/products/<?php echo $product['image']; ?>"
                         alt="View 2" class="thumbnail-image">
                    <img src="assets/images/products/<?php echo $product['image']; ?>"
                         alt="View 3" class="thumbnail-image">
                    <img src="assets/images/products/<?php echo $product['image']; ?>"
                         alt="View 4" class="thumbnail-image">
                </div>
            </div>

            <!-- Product Info -->
            <div class="product-info">
                <div class="product-category">
                    <?php echo ucfirst($product['category']); ?>
                </div>
                
                <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                
                <div class="rating-container">
                    <div class="stars">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                        <span class="star <?php echo $i <= $avg_rating ? '' : 'empty'; ?>">★</span>
                        <?php endfor; ?>
                    </div>
                    <span class="rating-text"><?php echo $avg_rating; ?> (<?php echo $total_reviews; ?> reviews)</span>
                </div>
                
                <div class="product-price-section">
                    <div class="product-price-large">$<?php echo number_format($product['price'], 2); ?></div>
                    <div class="stock-status <?php echo $product['stock'] > 0 ? 'in-stock' : 'out-of-stock'; ?>">
                        <?php echo $product['stock'] > 0 ? '✓ In Stock' : '✗ Out of Stock'; ?>
                    </div>
                </div>
                
                <div class="product-description">
                    <p><?php echo nl2br(htmlspecialchars($product['description'] ?? 'Handmade with love and care. Each piece is unique and crafted to bring joy to your life. Made from premium quality yarn with attention to every detail.')); ?></p>
                </div>
                
                <?php if ($product['stock'] > 0): ?>
                <div class="quantity-section">
                    <label>Quantity:</label>
                    <div class="quantity-selector-large">
                        <button class="quantity-btn-large" onclick="changeQuantity(-1)">−</button>
                        <input type="number" id="quantity" class="quantity-input-large" value="1" 
                               min="1" max="<?php echo $product['stock']; ?>" readonly>
                        <button class="quantity-btn-large" onclick="changeQuantity(1)">+</button>
                    </div>
                </div>
                
                <div class="action-buttons">
                    <button class="btn-add-cart" onclick="addToCartFromProduct()">
                        Add to Cart
                    </button>
                    <button class="btn-wishlist-large" onclick="addToWishlist(<?php echo $product['id']; ?>)">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                        </svg>
                        Wishlist
                    </button>
                </div>
                <?php else: ?>
                <div style="text-align: center; padding: 2rem; background: #FFE4E9; border-radius: 20px; color: var(--deep-rose); font-weight: 600;">
                    Currently Out of Stock
                </div>
                <?php endif; ?>
                
                <div class="product-features">
                    <div class="feature-item">
                        <span class="feature-icon">🧶</span>
                        <span>Handmade with Premium Yarn</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">🎁</span>
                        <span>Beautiful Gift Packaging</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">🚚</span>
                        <span>Free Shipping on Orders Over $50</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">♻️</span>
                        <span>Eco-Friendly Materials</span>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">💖</span>
                        <span>Made with Love & Care</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Reviews Section -->
        <div class="reviews-section">
            <div class="reviews-header">
                <h2>Customer Reviews</h2>
                <div class="rating-container">
                    <div class="stars">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                        <span class="star <?php echo $i <= $avg_rating ? '' : 'empty'; ?>">★</span>
                        <?php endfor; ?>
                    </div>
                    <span class="rating-text"><?php echo $avg_rating; ?> out of 5</span>
                </div>
            </div>
            
            <?php if ($reviews->num_rows > 0): ?>
                <?php while ($review = $reviews->fetch_assoc()): ?>
                <div class="review-card">
                    <div class="review-header">
                        <div class="reviewer-info">
                            <div class="reviewer-avatar">
                                <?php echo strtoupper(substr($review['user_name'], 0, 1)); ?>
                            </div>
                            <div>
                                <div style="font-weight: 600;"><?php echo htmlspecialchars($review['user_name']); ?></div>
                                <div class="stars">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                    <span class="star" style="font-size: 1rem; <?php echo $i > $review['rating'] ? 'opacity: 0.3;' : ''; ?>">★</span>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        </div>
                        <div class="review-date">
                            <?php echo date('M d, Y', strtotime($review['created_at'])); ?>
                        </div>
                    </div>
                    <div class="review-comment">
                        <?php echo nl2br(htmlspecialchars($review['comment'])); ?>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p style="text-align: center; color: var(--text-light); padding: 2rem;">No reviews yet. Be the first to review this product!</p>
            <?php endif; ?>
            
            <?php if (isLoggedIn()): ?>
            <div class="add-review-form">
                <h3>Write a Review</h3>
                <form id="reviewForm" onsubmit="submitReview(event)">
                    <div class="form-group">
                        <label>Your Rating:</label>
                        <div class="rating-input" id="ratingInput">
                            <span class="star-input" data-rating="1">★</span>
                            <span class="star-input" data-rating="2">★</span>
                            <span class="star-input" data-rating="3">★</span>
                            <span class="star-input" data-rating="4">★</span>
                            <span class="star-input" data-rating="5">★</span>
                        </div>
                        <input type="hidden" id="rating" name="rating" value="5">
                    </div>
                    <div class="form-group">
                        <label>Your Review:</label>
                        <textarea class="form-textarea" name="comment" required placeholder="Share your experience with this product..."></textarea>
                    </div>
                    <button type="submit" class="btn-primary">Submit Review</button>
                </form>
            </div>
            <?php else: ?>
            <div style="text-align: center; padding: 2rem; background: var(--soft-pink); border-radius: 20px; margin-top: 2rem;">
                <p style="margin-bottom: 1rem;">Please <a href="/login.php" style="color: var(--deep-rose); font-weight: 600;">login</a> to write a review</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Related Products -->
        <?php if ($related_products->num_rows > 0): ?>
        <div class="related-products">
            <h2 class="section-title">You May Also Like</h2>
            <div class="product-grid">
                <?php while ($related = $related_products->fetch_assoc()): ?>
                <div class="product-card reveal">
                    <?php if ($related['is_trending']): ?>
                    <span class="product-badge">Trending</span>
                    <?php endif; ?>
                    
                    <div class="product-image-container">
                        <img src="assets/images/products/<?php echo $related['image']; ?>"
                             alt="<?php echo htmlspecialchars($related['name']); ?>" 
                             class="product-image">
                    </div>
                    
                    <div class="product-info">
                        <h3 class="product-name"><?php echo htmlspecialchars($related['name']); ?></h3>
                        <p class="product-price">$<?php echo number_format($related['price'], 2); ?></p>
                        <div class="product-actions">
                            <a href="product.php?id=<?php echo $related['id']; ?>">
                                <button class="add-to-cart-btn">View Details</button>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care.</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="shop.php">Shop</a>
                <a href="collections.php">Collections</a>
                <a href="about.php">About</a>
            </div>
            <div class="footer-section">
                <h3>Customer Care</h3>
                <a href="#">Shipping Info</a>
                <a href="#">Returns</a>
                <a href="#">FAQ</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 YARNIFY. Made with 💖</p>
        </div>
    </footer>

    <a href="https://wa.me/1234567890" class="whatsapp-float" target="_blank">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="white">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
    </a>

    <script src="assets/js/main.js"></script>
    <script>
        const productId = <?php echo $product_id; ?>;
        const maxStock = <?php echo $product['stock']; ?>;
        
        function changeQuantity(change) {
            const input = document.getElementById('quantity');
            const current = parseInt(input.value);
            const newValue = current + change;
            
            if (newValue >= 1 && newValue <= maxStock) {
                input.value = newValue;
            }
        }
        
        function addToCartFromProduct() {
            const quantity = parseInt(document.getElementById('quantity').value);
            addToCart(productId, quantity);
        }
        
        // Rating input
        const ratingStars = document.querySelectorAll('.star-input');
        const ratingInput = document.getElementById('rating');
        
        ratingStars.forEach(star => {
            star.addEventListener('click', function() {
                const rating = this.getAttribute('data-rating');
                ratingInput.value = rating;
                
                ratingStars.forEach((s, index) => {
                    if (index < rating) {
                        s.classList.add('selected');
                    } else {
                        s.classList.remove('selected');
                    }
                });
            });
        });
        
        // Set all stars as selected by default
        ratingStars.forEach(star => star.classList.add('selected'));
        
        function submitReview(e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('product_id', productId);
            
            fetch('submit-review.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification('Review submitted! It will appear after approval.', 'success');
                    e.target.reset();
                    ratingStars.forEach(star => star.classList.add('selected'));
                } else {
                    showNotification(data.message || 'Failed to submit review', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Something went wrong', 'error');
            });
        }
    </script>
</body>
</html>
