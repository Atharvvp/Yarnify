# 🚀 Quick Start Guide - Crochet Luxury

## 📋 Prerequisites Checklist

Before you begin, ensure you have:
- ✅ PHP 7.4 or higher installed
- ✅ MySQL 5.7 or higher installed
- ✅ Apache or Nginx web server
- ✅ Basic knowledge of PHP and MySQL

## ⚡ Quick Installation (5 Minutes)

### Step 1: Database Setup (2 minutes)

1. **Create Database**
```sql
CREATE DATABASE crochet_luxury CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

2. **Import Schema**
```bash
# Using command line
mysql -u your_username -p crochet_luxury < database.sql

# OR using phpMyAdmin:
# - Open phpMyAdmin
# - Select 'crochet_luxury' database
# - Click 'Import' tab
# - Choose 'database.sql' file
# - Click 'Go'
```

### Step 2: Configure Database Connection (1 minute)

Edit `config/db.php` and update these lines:

```php
define('DB_HOST', 'localhost');       // Usually 'localhost'
define('DB_USER', 'your_username');   // Your MySQL username
define('DB_PASS', 'your_password');   // Your MySQL password
define('DB_NAME', 'crochet_luxury');  // Database name
```

### Step 3: Set File Permissions (1 minute)

```bash
# Make uploads directory writable
chmod 755 assets/images/products

# For Linux/Mac users
chmod 755 config/
```

### Step 4: Access the Website (1 minute)

1. **Start your web server** (if not already running)
   - For XAMPP: Start Apache and MySQL
   - For WAMP: Start All Services
   - For MAMP: Start Servers

2. **Open in browser**
   ```
   http://localhost/crochet-luxury-shop/
   ```

3. **Admin Login**
   ```
   URL: http://localhost/crochet-luxury-shop/admin/dashboard.php
   Email: admin@crochetluxury.com
   Password: admin123
   ```

## 🎨 Adding Sample Product Images

The database includes 8 sample products. To display them properly:

1. Create placeholder images in `assets/images/products/`:
   - pink-tote.jpg
   - blossom-bag.jpg
   - rose-top.jpg
   - daisy-top.jpg
   - bunny-plush.jpg
   - bear-plush.jpg
   - scrunchie-set.jpg
   - hair-clips.jpg

2. **Quick tip**: Use 500x500px square images in JPG format

## 🔧 Common Setup Issues & Solutions

### Issue 1: "Connection failed" Error
**Cause**: Incorrect database credentials
**Solution**: 
1. Verify MySQL is running
2. Check username/password in `config/db.php`
3. Ensure database exists: `SHOW DATABASES;`

### Issue 2: "Cannot modify header information"
**Cause**: Output sent before headers
**Solution**: 
1. Check for whitespace before `<?php` tags
2. Ensure UTF-8 encoding without BOM

### Issue 3: 404 Errors on Pages
**Cause**: Missing .htaccess or mod_rewrite
**Solution**:
1. Enable mod_rewrite in Apache:
   ```bash
   sudo a2enmod rewrite
   sudo service apache2 restart
   ```
2. Create .htaccess in root directory (see below)

### Issue 4: Images Not Displaying
**Cause**: Incorrect file permissions
**Solution**:
```bash
chmod 755 assets/images/products/
```

## 📝 .htaccess Configuration

Create `.htaccess` in project root:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /crochet-luxury-shop/
    
    # Remove .php extension
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME}\.php -f
    RewriteRule ^(.*)$ $1.php [L]
    
    # Prevent directory browsing
    Options -Indexes
</IfModule>

# Prevent access to config files
<FilesMatch "^(config|database)\.">
    Order allow,deny
    Deny from all
</FilesMatch>

# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>

# Browser caching
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

## 🔐 Security Checklist (IMPORTANT!)

After installation, immediately:

1. **Change Admin Password**
   - Login to admin panel
   - Go to profile settings
   - Update password from 'admin123'

2. **Update CSRF Token Salt** (in config/db.php)
   ```php
   // Generate new random salt
   $_SESSION['csrf_salt'] = bin2hex(random_bytes(32));
   ```

3. **Secure Database User**
   - Create dedicated MySQL user (don't use root)
   ```sql
   CREATE USER 'crochet_user'@'localhost' IDENTIFIED BY 'strong_password';
   GRANT ALL PRIVILEGES ON crochet_luxury.* TO 'crochet_user'@'localhost';
   FLUSH PRIVILEGES;
   ```

4. **Set Proper File Permissions**
   ```bash
   # Files: 644
   find . -type f -exec chmod 644 {} \;
   
   # Directories: 755
   find . -type d -exec chmod 755 {} \;
   
   # Config files: 640
   chmod 640 config/db.php
   ```

## 🎯 Next Steps

### For Development:
1. ✅ Test all pages (shop, cart, checkout)
2. ✅ Add real product images
3. ✅ Customize colors and branding
4. ✅ Test admin panel features
5. ✅ Configure email settings

### For Production:
1. ✅ Enable error logging (disable display_errors)
2. ✅ Set up SSL certificate (HTTPS)
3. ✅ Configure production database
4. ✅ Set up automated backups
5. ✅ Optimize images and assets
6. ✅ Configure CDN (optional)
7. ✅ Set up email notifications
8. ✅ Integrate payment gateway

## 📊 Testing Checklist

- [ ] Homepage loads correctly
- [ ] Can browse products
- [ ] Can add items to cart
- [ ] Can register new account
- [ ] Can login/logout
- [ ] Can place order (if logged in)
- [ ] Can add items to wishlist
- [ ] Admin can login
- [ ] Admin can add products
- [ ] Admin can manage orders
- [ ] Search functionality works
- [ ] Mobile responsive design
- [ ] All images display

## 💡 Tips for Success

1. **Start Simple**: Test with a few products first
2. **Use Real Images**: Product photos greatly impact sales
3. **Test Mobile**: Most users shop on mobile devices
4. **Backup Regularly**: Database backups are crucial
5. **Monitor Performance**: Use browser dev tools

## 🆘 Getting Help

### If you encounter issues:

1. **Check Error Logs**
   ```bash
   # Apache error log (Ubuntu)
   tail -f /var/log/apache2/error.log
   
   # PHP error log
   tail -f /var/log/php/error.log
   ```

2. **Enable PHP Error Display** (development only)
   ```php
   // Add to top of index.php temporarily
   ini_set('display_errors', 1);
   error_reporting(E_ALL);
   ```

3. **Check MySQL Connection**
   ```php
   // Create test.php
   <?php
   $conn = new mysqli('localhost', 'username', 'password', 'crochet_luxury');
   if ($conn->connect_error) {
       die("Failed: " . $conn->connect_error);
   }
   echo "Connected successfully!";
   ?>
   ```

## 🎉 Success!

You should now have a fully functional luxury e-commerce website!

**Test URLs**:
- Homepage: `http://localhost/crochet-luxury-shop/`
- Shop: `http://localhost/crochet-luxury-shop/shop.php`
- Admin: `http://localhost/crochet-luxury-shop/admin/dashboard.php`

## 📞 Support Resources

- PHP Documentation: https://www.php.net/manual/
- MySQL Reference: https://dev.mysql.com/doc/
- MDN Web Docs: https://developer.mozilla.org/

---

**Happy Selling! 💖🧶**
