<?php
require_once 'config/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$response = ['success' => false, 'message' => 'Please login to use wishlist'];

if (!isLoggedIn()) {
    echo json_encode($response);
    exit;
}

try {
    $user_id = $_SESSION['user_id'];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';

        if ($action === 'add') {
            $product_id = (int)($_POST['product_id'] ?? 0);

            if ($product_id > 0) {
                // Check if product exists
                $check_product = $conn->prepare("SELECT id FROM products WHERE id = ?");
                $check_product->bind_param("i", $product_id);
                $check_product->execute();
                $product_exists = $check_product->get_result()->num_rows > 0;
                $check_product->close();

                if (!$product_exists) {
                    $response['message'] = 'Product not found';
                    echo json_encode($response);
                    exit;
                }

                // Check if already in wishlist
                $check_stmt = $conn->prepare("SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?");
                $check_stmt->bind_param("ii", $user_id, $product_id);
                $check_stmt->execute();

                if ($check_stmt->get_result()->num_rows > 0) {
                    $response['message'] = 'Already in wishlist';
                } else {
                    $stmt = $conn->prepare("INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)");
                    $stmt->bind_param("ii", $user_id, $product_id);

                    if ($stmt->execute()) {
                        $response['success'] = true;
                        $response['message'] = 'Added to wishlist!';
                    } else {
                        $response['message'] = 'Failed to add to wishlist';
                    }
                    $stmt->close();
                }
                $check_stmt->close();
            }

        } elseif ($action === 'remove') {
            $product_id = (int)($_POST['product_id'] ?? 0);

            if ($product_id > 0) {
                $stmt = $conn->prepare("DELETE FROM wishlist WHERE user_id = ? AND product_id = ?");
                $stmt->bind_param("ii", $user_id, $product_id);

                if ($stmt->execute()) {
                    $response['success'] = true;
                    $response['message'] = 'Removed from wishlist';
                } else {
                    $response['message'] = 'Failed to remove from wishlist';
                }
                $stmt->close();
            }
        }

    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';

        if ($action === 'count') {
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM wishlist WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();

            $response['success'] = true;
            $response['count'] = $row['count'];
            $stmt->close();
        }
    }

} catch (Exception $e) {
    $response['message'] = 'Server error: ' . $e->getMessage();
    error_log('Wishlist handler error: ' . $e->getMessage());
}

echo json_encode($response);
?>