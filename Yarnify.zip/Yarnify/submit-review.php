<?php
require_once 'config/db.php';
requireLogin();

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $rating = (int)($_POST['rating'] ?? 0);
    $comment = sanitize($_POST['comment'] ?? '');
    $user_id = $_SESSION['user_id'];
    
    if (!$product_id || !$rating || !$comment) {
        $response['message'] = 'All fields are required';
    } elseif ($rating < 1 || $rating > 5) {
        $response['message'] = 'Invalid rating';
    } else {
        $stmt = $conn->prepare("INSERT INTO reviews (product_id, user_id, rating, comment, status) VALUES (?, ?, ?, ?, 'pending')");
        $stmt->bind_param("iiis", $product_id, $user_id, $rating, $comment);
        
        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Review submitted successfully';
        } else {
            $response['message'] = 'Failed to submit review';
        }
        $stmt->close();
    }
}

echo json_encode($response);
?>
