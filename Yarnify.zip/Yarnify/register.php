<?php
require_once 'config/db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request';
    } else {
        $name = sanitize($_POST['name'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (!$name || !$email || !$password || !$confirm_password) {
            $error = 'All fields are required';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format';
        } else {
            // Check if email already exists
            $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $check_stmt->bind_param("s", $email);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();

            if ($check_result->num_rows > 0) {
                $error = 'Email already registered';
            } else {
                // Insert new user
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'customer')");
                $stmt->bind_param("sss", $name, $email, $hashed_password);

                if ($stmt->execute()) {
                    // Set success message and redirect to login page
                    $success = 'Registration successful! Redirecting to login page...';

                    // Redirect to login page after 2 seconds
                    header("refresh:2;url=login.php");

                } else {
                    $error = 'Registration failed. Please try again.';
                }
                $stmt->close();
            }
            $check_stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Crochet Luxury</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--gradient-pink);
            padding: 2rem;
        }

        .auth-card {
            background: white;
            padding: 3rem;
            border-radius: 30px;
            box-shadow: var(--shadow-strong);
            max-width: 450px;
            width: 100%;
        }

        .auth-card h1 {
            text-align: center;
            margin-bottom: 0.5rem;
            font-size: 2.5rem;
        }

        .auth-card p {
            text-align: center;
            color: var(--text-light);
            margin-bottom: 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--text-dark);
        }

        .form-input {
            width: 100%;
            padding: 1rem 1.5rem;
            border: 2px solid var(--soft-pink);
            border-radius: 25px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: all 0.4s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--deep-rose);
            box-shadow: var(--glow-pink);
        }

        .alert {
            padding: 1rem;
            border-radius: 15px;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .alert-error {
            background: #FFE4E9;
            color: #D85D7A;
            border: 1px solid #FFC0CB;
        }

        .alert-success {
            background: #E8F5E9;
            color: #2E7D32;
            border: 1px solid #66BB6A;
        }

        .auth-link {
            text-align: center;
            margin-top: 1.5rem;
            color: var(--text-light);
        }

        .auth-link a {
            color: var(--deep-rose);
            font-weight: 600;
        }

        .auth-link a:hover {
            text-decoration: underline;
        }

        .password-strength {
            margin-top: 0.5rem;
            font-size: 0.85rem;
        }

        .strength-weak { color: #E5989B; }
        .strength-medium { color: #F0AD4E; }
        .strength-strong { color: #5CB85C; }
    </style>
<link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card fade-in">
            <h1>Join Us! 💖</h1>
            <p>Create your account and start shopping</p>

            <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
                <br><br>
                <div style="font-size: 0.9rem;">If you are not redirected automatically, <a href="login.php" style="color: #2E7D32; text-decoration: underline;">click here to login</a></div>
            </div>
            <?php endif; ?>

            <?php if (!$success): ?>
            <form method="POST" action="" id="registerForm">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">

                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" class="form-input" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" class="form-input" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-input" required minlength="6">
                    <div id="passwordStrength" class="password-strength"></div>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-input" required>
                </div>

                <button type="submit" class="btn-primary" style="width: 100%; margin-top: 1rem;">Create Account</button>
            </form>

            <div class="auth-link">
                Already have an account? <a href="login.php">Login here</a>
            </div>

            <div class="auth-link">
                <a href="index.php">← Back to Home</a>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!$success): ?>
    <script>
        // Password strength indicator
        const passwordInput = document.getElementById('password');
        const strengthDiv = document.getElementById('passwordStrength');

        passwordInput.addEventListener('input', () => {
            const password = passwordInput.value;
            let strength = 0;

            if (password.length >= 6) strength++;
            if (password.length >= 10) strength++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^a-zA-Z0-9]/.test(password)) strength++;

            if (strength === 0) {
                strengthDiv.textContent = '';
            } else if (strength <= 2) {
                strengthDiv.textContent = '❌ Weak password';
                strengthDiv.className = 'password-strength strength-weak';
            } else if (strength <= 3) {
                strengthDiv.textContent = '⚠️ Medium strength';
                strengthDiv.className = 'password-strength strength-medium';
            } else {
                strengthDiv.textContent = '✅ Strong password';
                strengthDiv.className = 'password-strength strength-strong';
            }
        });

        // Confirm password validation
        document.getElementById('registerForm').addEventListener('submit', (e) => {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;

            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
            }
        });
    </script>
    <?php endif; ?>
</body>
</html>