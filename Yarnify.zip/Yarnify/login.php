<?php
require_once 'config/db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request';
    } else {
        $email = sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if ($email && $password) {
            $stmt = $conn->prepare("SELECT id, name, email, password, role, status FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($user = $result->fetch_assoc()) {
                if ($user['status'] === 'blocked') {
                    $error = 'Your account has been blocked';
                } elseif (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    
                    if ($user['role'] === 'admin') {
                        header('Location: admin/dashboard.php');
                    } else {
                        header('Location: index.php');
                    }
                    exit();
                } else {
                    $error = 'Invalid email or password';
                }
            } else {
                $error = 'Invalid email or password';
            }
            $stmt->close();
        } else {
            $error = 'Please fill in all fields';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - YARNIFY</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--gradient-pink);
            padding: 2rem;
        }
        
        .auth-card {
            background: white;
            padding: 3rem;
            border-radius: 30px;
            box-shadow: var(--shadow-strong);
            max-width: 450px;
            width: 100%;
        }
        
        .auth-card h1 {
            text-align: center;
            margin-bottom: 0.5rem;
            font-size: 2.5rem;
        }
        
        .auth-card p {
            text-align: center;
            color: var(--text-light);
            margin-bottom: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .form-input {
            width: 100%;
            padding: 1rem 1.5rem;
            border: 2px solid var(--soft-pink);
            border-radius: 25px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: all 0.4s ease;
        }
        
        .form-input:focus {
            outline: none;
            border-color: var(--deep-rose);
            box-shadow: var(--glow-pink);
        }
        
        .alert {
            padding: 1rem;
            border-radius: 15px;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        
        .alert-error {
            background: #FFE4E9;
            color: #D85D7A;
            border: 1px solid #FFC0CB;
        }
        
        .alert-success {
            background: #E8F5E9;
            color: #2E7D32;
            border: 1px solid #66BB6A;
        }
        
        .auth-link {
            text-align: center;
            margin-top: 1.5rem;
            color: var(--text-light);
        }
        
        .auth-link a {
            color: var(--deep-rose);
            font-weight: 600;
        }
        
        .auth-link a:hover {
            text-decoration: underline;
        }
    </style>
<link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <div class="auth-container">
        <div class="auth-card fade-in">
            <h1>Welcome Back! 💖</h1>
            <p>Login to continue shopping</p>
            
            <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-input" required>
                </div>
                
                <button type="submit" class="btn-primary" style="width: 100%; margin-top: 1rem;">Login</button>
            </form>
            
            <div class="auth-link">
                Don't have an account? <a href="register.php">Register here</a>
            </div>
            
            <div class="auth-link">
                <a href="index.php">← Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>
