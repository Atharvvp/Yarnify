<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialize cart session variable if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Initialize user session if testing
if (!isset($_SESSION['user_id'])) {
    // For testing, set a dummy user (remove in production)
    // $_SESSION['user_id'] = 1;
    // $_SESSION['user_email'] = 'test@example.com';
    // $_SESSION['user_name'] = 'Test User';
}
?>