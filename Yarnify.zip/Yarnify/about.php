<?php require_once 'config/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - YARNIFY</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .about-hero {
            background: var(--gradient-pink);
            padding: 8rem 5% 4rem;
            text-align: center;
            margin-top: 0px;
        }

        .about-hero h1 {
            font-size: 4rem;
            margin-bottom: 1rem;
        }

        .about-section {
            max-width: 1200px;
            margin: 0 auto;
            padding: 4rem 5%;
        }

        .about-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            align-items: center;
            margin-bottom: 4rem;
        }

        .about-text h2 {
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
            color: var(--deep-rose);
        }

        .about-text p {
            font-size: 1.1rem;
            line-height: 1.8;
            color: var(--text-dark);
            margin-bottom: 1rem;
        }

        .about-image {
            width: 100%;
            height: 400px;
            background: var(--soft-pink);
            border-radius: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 8rem;
        }

        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }

        .value-card {
            background: white;
            padding: 2rem;
            border-radius: 20px;
            text-align: center;
            box-shadow: var(--shadow-soft);
        }

        .value-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .value-title {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: var(--deep-rose);
        }

        @media (max-width: 968px) {
            .about-grid {
                grid-template-columns: 1fr;
            }

            .about-hero h1 {
                font-size: 2.5rem;
            }
        }
    </style>
<link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>

        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>

        <div class="nav-right">
            <a href="<?php echo isset($_SESSION['user_id']) ? 'wishlist.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
            </a>
            <a href="<?php echo isset($_SESSION['user_id']) ? 'cart.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
            </a>
            <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
    </nav>

    <div class="about-hero">
        <h1>About YARNIFY</h1>
        <p style="font-size: 1.3rem; color: var(--text-light);">Handmade with love, crafted for you</p>
    </div>

    <div class="about-section">
        <div class="about-grid reveal">
            <div class="about-text">
                <h2>Our Story</h2>
                <p>YARNIFY was born from a passion for creating beautiful, handmade pieces that bring joy to everyday life. Each item in our collection is carefully crafted with premium materials and attention to detail.</p>
                <p>What started as a small hobby has grown into a brand dedicated to celebrating the art of crochet while maintaining sustainable and ethical practices.</p>
            </div>
            <div class="about-image">
                🧶
            </div>
        </div>

        <div class="about-grid reveal" style="flex-direction: row-reverse;">
            <div class="about-text">
                <h2>Our Mission</h2>
                <p>We believe in the power of handmade craftsmanship. Every stitch tells a story, and every piece is created with love and dedication.</p>
                <p>Our mission is to bring luxury crochet pieces into homes worldwide, combining traditional techniques with modern designs.</p>
            </div>
            <div class="about-image">
                💖
            </div>
        </div>

        <h2 style="text-align: center; font-size: 3rem; margin: 4rem 0 2rem; color: var(--deep-rose);">Our Values</h2>

        <div class="values-grid">
            <div class="value-card reveal">
                <div class="value-icon">🌱</div>
                <h3 class="value-title">Sustainable</h3>
                <p>We use eco-friendly materials and sustainable practices</p>
            </div>

            <div class="value-card reveal">
                <div class="value-icon">✨</div>
                <h3 class="value-title">Quality</h3>
                <p>Every piece is made with premium materials and care</p>
            </div>

            <div class="value-card reveal">
                <div class="value-icon">💝</div>
                <h3 class="value-title">Handmade</h3>
                <p>Each item is lovingly crafted by hand</p>
            </div>

            <div class="value-card reveal">
                <div class="value-icon">🌸</div>
                <h3 class="value-title">Unique</h3>
                <p>No two pieces are exactly alike</p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care. Each item is unique and crafted to bring joy to your life.</p>
                <p>Yarnify is a handmade crochet brand offering affordable and customizable accessories crafted with love.</p>
                <div class="social-links">
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-9-9 9 9 0 0 1 9-9c2.5 0 4.8.9 6.5 2.4"/>
                            <path d="M16 8h-2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v-4h-1"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <path d="M22 6l-10 7L2 6"/>
                        </svg>
                    </a>
                </div>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="shop.php">Shop</a>
                <a href="collections.php">Collections</a>
                <a href="about.php">About</a>
                <a href="reviews.php">Reviews</a>
            </div>
            <div class="footer-section">
                <h3>Customer Care</h3>
                <a href="#">Shipping Info</a>
                <a href="#">Returns</a>
                <a href="#">FAQ</a>
                <a href="#">Contact Us</a>
            </div>
            <div class="footer-section">
                <h3>Newsletter</h3>
                <p>Subscribe for exclusive offers and updates!</p>
                <form style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                    <input type="email" placeholder="Your email" style="flex: 1; padding: 0.8rem; border-radius: 25px; border: none;">
                    <button type="submit" class="btn-primary" style="padding: 0.8rem 1.5rem;">Join</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 YARNIFY. Made with 💖 | All Rights Reserved</p>
        </div>
    </footer>


    <script src="main.js"></script>
</body>
</html>
