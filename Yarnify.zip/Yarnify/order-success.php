<?php
require_once 'config/db.php';
requireLogin();

$order_id = (int)($_GET['order_id'] ?? 0);

if (!$order_id) {
    header('Location: shop.php');
    exit();
}

// Fetch order details
$stmt = $conn->prepare("SELECT o.*, u.name as customer_name FROM orders o 
                        JOIN users u ON o.user_id = u.id 
                        WHERE o.id = ? AND o.user_id = ?");
$stmt->bind_param("ii", $order_id, $_SESSION['user_id']);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    header('Location: shop.php');
    exit();
}

// Fetch order items
$items_stmt = $conn->prepare("SELECT oi.*, p.name, p.image FROM order_items oi 
                               JOIN products p ON oi.product_id = p.id 
                               WHERE oi.order_id = ?");
$items_stmt->bind_param("i", $order_id);
$items_stmt->execute();
$order_items = $items_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmed - Crochet Luxury</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .success-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--gradient-pink);
            padding: 2rem;
        }
        
        .success-card {
            background: white;
            padding: 4rem 3rem;
            border-radius: 30px;
            box-shadow: var(--shadow-strong);
            max-width: 800px;
            width: 100%;
            text-align: center;
        }
        
        .checkmark-circle {
            width: 120px;
            height: 120px;
            background: var(--gradient-pink);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 2rem;
            animation: scaleIn 0.5s ease;
        }
        
        .checkmark {
            font-size: 4rem;
            color: var(--deep-rose);
            animation: checkmarkAppear 0.5s ease 0.3s both;
        }
        
        @keyframes scaleIn {
            from {
                transform: scale(0);
            }
            to {
                transform: scale(1);
            }
        }
        
        @keyframes checkmarkAppear {
            from {
                opacity: 0;
                transform: scale(0);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
        
        .success-card h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--deep-rose);
        }
        
        .success-card p {
            font-size: 1.2rem;
            color: var(--text-light);
            margin-bottom: 3rem;
        }
        
        .order-info-box {
            background: var(--light-pink);
            padding: 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            text-align: left;
        }
        
        .order-info-row {
            display: flex;
            justify-content: space-between;
            padding: 1rem 0;
            border-bottom: 1px solid var(--soft-pink);
        }
        
        .order-info-row:last-child {
            border-bottom: none;
        }
        
        .order-info-label {
            color: var(--text-light);
        }
        
        .order-info-value {
            font-weight: 600;
            color: var(--text-dark);
        }
        
        .order-items-list {
            background: var(--soft-pink);
            padding: 1.5rem;
            border-radius: 15px;
            margin: 1rem 0;
        }
        
        .order-item-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.8rem 0;
        }
        
        .success-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
        }
        
        .order-total-box {
            background: var(--gradient-pink);
            padding: 1.5rem;
            border-radius: 15px;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--deep-rose);
            margin-top: 1rem;
        }
    </style>
<link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <div class="success-container">
        <div class="success-card fade-in">
            <div class="checkmark-circle">
                <div class="checkmark">✓</div>
            </div>
            
            <h1>Order Placed Successfully!</h1>
            <p>Thank you for your purchase. Your order has been confirmed and will be processed soon.</p>
            
            <div class="order-info-box">
                <div class="order-info-row">
                    <span class="order-info-label">Order Number:</span>
                    <span class="order-info-value">#<?php echo $order['id']; ?></span>
                </div>
                
                <div class="order-info-row">
                    <span class="order-info-label">Order Date:</span>
                    <span class="order-info-value"><?php echo date('F d, Y', strtotime($order['created_at'])); ?></span>
                </div>
                
                <div class="order-info-row">
                    <span class="order-info-label">Payment Method:</span>
                    <span class="order-info-value"><?php echo strtoupper($order['payment_method']); ?></span>
                </div>
                
                <div class="order-info-row">
                    <span class="order-info-label">Shipping Address:</span>
                    <span class="order-info-value">
                        <?php echo htmlspecialchars($order['shipping_address']); ?>, 
                        <?php echo htmlspecialchars($order['shipping_city']); ?>, 
                        <?php echo htmlspecialchars($order['shipping_state']); ?> 
                        <?php echo htmlspecialchars($order['shipping_zip']); ?>
                    </span>
                </div>
            </div>
            
            <h3 style="text-align: left; margin-bottom: 1rem; color: var(--deep-rose);">Order Items:</h3>
            <div class="order-items-list">
                <?php while ($item = $order_items->fetch_assoc()): ?>
                <div class="order-item-row">
                    <span><?php echo htmlspecialchars($item['name']); ?> × <?php echo $item['quantity']; ?></span>
                    <span style="font-weight: 600;">$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                </div>
                <?php endwhile; ?>
            </div>
            
            <div class="order-total-box">
                Total Amount: $<?php echo number_format($order['final_amount'], 2); ?>
            </div>
            
            <div style="background: var(--light-pink); padding: 1.5rem; border-radius: 15px; margin-top: 2rem;">
                <p style="margin: 0; font-size: 1rem;">📧 A confirmation email has been sent to <strong><?php echo htmlspecialchars($order['shipping_email']); ?></strong></p>
            </div>
            
            <div class="success-buttons">
                <a href="profile.php">
                    <button class="btn-secondary" style="padding: 1rem 2rem;">View My Orders</button>
                </a>
                <a href="shop.php">
                    <button class="btn-primary" style="padding: 1rem 2rem;">Continue Shopping</button>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
