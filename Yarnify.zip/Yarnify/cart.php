<?php
require_once 'config/db.php';

// Remove duplicate session_start() as it's already in config/db.php

$cart_items = [];
$total = 0;

// Get cart count for badge
$cart_count = 0;
if (!empty($_SESSION['cart'])) {
    $cart_count = array_sum($_SESSION['cart']);
    $_SESSION['cart_count'] = $cart_count;

    $product_ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($product_ids), '?'));

    // Prepare and execute query to get cart items
    $query = "SELECT * FROM products WHERE id IN ($placeholders)";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $types = str_repeat('i', count($product_ids));
        if (!empty($product_ids)) {
            $stmt->bind_param($types, ...$product_ids);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        while ($product = $result->fetch_assoc()) {
            $quantity = $_SESSION['cart'][$product['id']];
            $subtotal = $product['price'] * $quantity;
            $total += $subtotal;

            $cart_items[] = [
                'product' => $product,
                'quantity' => $quantity,
                'subtotal' => $subtotal
            ];
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - YARNIFY</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        :root {
            --deep-rose: #D85D7A;
            --soft-pink: #FFE4E9;
            --light-pink: #FFF0F5;
            --text-dark: #333;
            --text-light: #666;
            --border-color: #E9E9E9;
            --shadow-soft: 0 4px 12px rgba(0, 0, 0, 0.05);
            --shadow-medium: 0 8px 20px rgba(0, 0, 0, 0.1);
            --glow-pink: 0 0 20px rgba(216, 93, 122, 0.3);
        }

        .cart-container {
            max-width: 1200px;
            margin: 120px auto 3rem;
            padding: 0 5%;
        }

        .cart-header {
            text-align: center;
            margin-bottom: 3rem;
        }

        .cart-header h1 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
            color: var(--deep-rose);
            font-family: 'Playfair Display', serif;
        }

        .cart-grid {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 2rem;
        }

        .cart-items {
            background: white;
            border-radius: 30px;
            padding: 2rem;
            box-shadow: var(--shadow-soft);
        }

        .cart-item {
            display: grid;
            grid-template-columns: 120px 1fr auto;
            gap: 1.5rem;
            padding: 1.5rem 0;
            border-bottom: 1px solid var(--soft-pink);
        }

        .cart-item:last-child {
            border-bottom: none;
        }

        .cart-item-image {
            width: 120px;
            height: 120px;
            border-radius: 20px;
            overflow: hidden;
            background: var(--soft-pink);
        }

        .cart-item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .cart-item-info h3 {
            font-size: 1.2rem;
            margin-bottom: 0.5rem;
            color: var(--text-dark);
            font-family: 'Poppins', sans-serif;
        }

        .cart-item-price {
            font-size: 1.3rem;
            color: var(--deep-rose);
            font-weight: 700;
            margin-bottom: 1rem;
            font-family: 'Poppins', sans-serif;
        }

        .quantity-selector {
            display: flex;
            align-items: center;
            gap: 1rem;
            background: var(--soft-pink);
            padding: 0.5rem;
            border-radius: 25px;
            width: fit-content;
        }

        .quantity-btn {
            width: 30px;
            height: 30px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--deep-rose);
            font-weight: 700;
            cursor: pointer;
            border: none;
        }

        .quantity-input {
            width: 50px;
            text-align: center;
            border: none;
            background: transparent;
            font-weight: 600;
            font-size: 1rem;
            font-family: 'Poppins', sans-serif;
        }

        .cart-item-actions {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            align-items: flex-end;
        }

        .remove-btn {
            color: #E5989B;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        .remove-btn:hover {
            color: #D85D7A;
        }

        .cart-summary {
            background: white;
            border-radius: 30px;
            padding: 2rem;
            box-shadow: var(--shadow-soft);
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        .cart-summary h2 {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            color: var(--deep-rose);
            font-family: 'Playfair Display', serif;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 1rem 0;
            border-bottom: 1px solid var(--soft-pink);
            font-family: 'Poppins', sans-serif;
        }

        .summary-row.total {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--deep-rose);
            border-bottom: none;
            margin-top: 1rem;
        }

        .coupon-form {
            margin: 1.5rem 0;
            display: flex;
            gap: 0.5rem;
        }

        .coupon-input {
            flex: 1;
            padding: 0.8rem 1rem;
            border: 2px solid var(--soft-pink);
            border-radius: 25px;
            font-family: 'Poppins', sans-serif;
        }

        .coupon-btn {
            padding: 0.8rem 1.5rem;
            background: var(--deep-rose);
            color: white;
            border-radius: 25px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
        }

        .checkout-btn {
            width: 100%;
            padding: 1.2rem;
            background: var(--deep-rose);
            color: white;
            border-radius: 30px;
            font-size: 1.1rem;
            font-weight: 700;
            margin-top: 1.5rem;
            box-shadow: var(--shadow-medium);
            border: none;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
        }

        .checkout-btn:hover {
            box-shadow: var(--glow-pink);
            transform: translateY(-3px);
        }

        .empty-cart {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: 30px;
            box-shadow: var(--shadow-soft);
        }

        .empty-cart h2 {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--deep-rose);
            font-family: 'Playfair Display', serif;
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 10px;
            color: white;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
            font-family: 'Poppins', sans-serif;
        }

        .notification.success {
            background-color: #4CAF50;
        }

        .notification.error {
            background-color: #F44336;
        }

        @keyframes slideIn {
            from { transform: translateX(100%); }
            to { transform: translateX(0); }
        }

        @media (max-width: 968px) {
            .cart-grid {
                grid-template-columns: 1fr;
            }

            .cart-summary {
                position: relative;
                top: 0;
            }
        }
    </style>
    <link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>

        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>

        <div class="nav-right">
            <a href="wishlist.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <span class="wishlist-count" style="display: none;">0</span>
            </a>
            <a href="cart.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
                <span class="cart-count" style="display: <?php echo $cart_count > 0 ? 'block' : 'none'; ?>;">
                    <?php echo $cart_count; ?>
                </span>
            </a>
            <a href="<?php echo isset($_SESSION['user_id']) ? 'profile.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
    </nav>

    <div class="cart-container">
        <div class="cart-header">
            <h1>Shopping Cart 🛍️</h1>
            <p style="color: var(--text-light); font-size: 1.1rem; font-family: 'Poppins', sans-serif;">
                <?php echo count($cart_items); ?> item(s) in your cart
            </p>
        </div>

        <?php if (empty($cart_items)): ?>
        <div class="empty-cart">
            <svg width="150" height="150" viewBox="0 0 24 24" fill="none" stroke="#FFC0CB" stroke-width="1">
                <circle cx="9" cy="21" r="1"/>
                <circle cx="20" cy="21" r="1"/>
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
            </svg>
            <h2>Your cart is empty</h2>
            <p style="color: var(--text-light); margin-bottom: 2rem; font-family: 'Poppins', sans-serif;">Add some beautiful handmade pieces to get started!</p>
            <a href="shop.php"><button class="btn-primary" style="font-family: 'Poppins', sans-serif;">Continue Shopping</button></a>
        </div>
        <?php else: ?>
        <div class="cart-grid">
            <div class="cart-items">
                <?php foreach ($cart_items as $item): ?>
                <div class="cart-item" data-product-id="<?php echo $item['product']['id']; ?>">
                    <div class="cart-item-image">
                        <img src="assets/images/products/<?php echo htmlspecialchars($item['product']['image']); ?>"
                             alt="<?php echo htmlspecialchars($item['product']['name']); ?>"
                             onerror="this.src='assets/images/placeholder-product.jpg'">
                    </div>

                    <div class="cart-item-info">
                        <h3><?php echo htmlspecialchars($item['product']['name']); ?></h3>
                        <div class="cart-item-price">₹<?php echo number_format($item['product']['price'], 2); ?></div>

                        <div class="quantity-selector">
                            <button class="quantity-btn quantity-minus" onclick="updateQuantity(<?php echo $item['product']['id']; ?>, -1)">−</button>
                            <input type="number" class="quantity-input" value="<?php echo $item['quantity']; ?>"
                                   max="<?php echo $item['product']['stock']; ?>" min="1" readonly>
                            <button class="quantity-btn quantity-plus" onclick="updateQuantity(<?php echo $item['product']['id']; ?>, 1)">+</button>
                        </div>
                    </div>

                    <div class="cart-item-actions">
                        <div style="font-size: 1.3rem; font-weight: 700; color: var(--deep-rose); font-family: 'Poppins', sans-serif;">
                            ₹<?php echo number_format($item['subtotal'], 2); ?>
                        </div>
                        <a class="remove-btn" onclick="removeFromCart(<?php echo $item['product']['id']; ?>)">Remove</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="cart-summary">
                <h2>Order Summary</h2>

                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span>₹<?php echo number_format($total, 2); ?></span>
                </div>

                <div class="summary-row">
                    <span>Shipping:</span>
                    <span>Free</span>
                </div>

                <div class="coupon-form">
                    <input type="text" class="coupon-input" placeholder="Coupon code" id="coupon-code">
                    <button type="button" class="coupon-btn" onclick="applyCoupon()">Apply</button>
                </div>

                <div class="summary-row total">
                    <span>Total:</span>
                    <span id="final-total">₹<?php echo number_format($total, 2); ?></span>
                </div>

                <a href="<?php echo isset($_SESSION['user_id']) ? 'checkout.php' : 'login.php'; ?>">
                    <button class="checkout-btn">Proceed to Checkout</button>
                </a>

                <a href="shop.php" style="display: block; text-align: center; margin-top: 1rem; color: var(--text-light); font-family: 'Poppins', sans-serif;">
                    ← Continue Shopping
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care. Each item is unique and crafted to bring joy to your life.</p>
                <p>Yarnify is a handmade crochet brand offering affordable and customizable accessories crafted with love.</p>
                <div class="social-links">
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-9-9 9 9 0 0 1 9-9c2.5 0 4.8.9 6.5 2.4"/>
                            <path d="M16 8h-2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v-4h-1"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <path d="M22 6l-10 7L2 6"/>
                        </svg>
                    </a>
                </div>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="shop.php">Shop</a>
                <a href="collections.php">Collections</a>
                <a href="about.php">About</a>
                <a href="reviews.php">Reviews</a>
            </div>
            <div class="footer-section">
                <h3>Customer Care</h3>
                <a href="#">Shipping Info</a>
                <a href="#">Returns</a>
                <a href="#">FAQ</a>
                <a href="#">Contact Us</a>
            </div>
            <div class="footer-section">
                <h3>Newsletter</h3>
                <p>Subscribe for exclusive offers and updates!</p>
                <form class="newsletter-form">
                    <input type="email" class="newsletter-input" placeholder="Your email">
                    <button type="submit" class="join-btn">Join</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 YARNIFY. Made with 💖 | All Rights Reserved</p>
        </div>
    </footer>

    <script>
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.textContent = message;
            document.body.appendChild(notification);

            setTimeout(() => {
                notification.style.opacity = '0';
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }, 3000);
        }

        function updateQuantity(productId, change) {
            const item = document.querySelector(`[data-product-id="${productId}"]`);
            const input = item.querySelector('.quantity-input');
            const currentQty = parseInt(input.value);
            const max = parseInt(input.max);
            const newQty = currentQty + change;

            if (newQty < 1 || newQty > max) {
                if (newQty < 1) {
                    showNotification('Minimum quantity is 1', 'error');
                } else {
                    showNotification('Cannot exceed available stock', 'error');
                }
                return;
            }

            fetch('cart-handler.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=update&product_id=${productId}&quantity=${newQty}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    showNotification(data.message || 'Failed to update quantity', 'error');
                }
            })
            .catch(error => {
                showNotification('An error occurred', 'error');
            });
        }

        function removeFromCart(productId) {
            if (!confirm('Remove this item from cart?')) return;

            fetch('cart-handler.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=remove&product_id=${productId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    showNotification(data.message || 'Failed to remove item', 'error');
                }
            })
            .catch(error => {
                showNotification('An error occurred', 'error');
            });
        }

        function applyCoupon() {
            const code = document.getElementById('coupon-code').value.trim();
            if (!code) {
                showNotification('Please enter a coupon code', 'error');
                return;
            }

            showNotification('Coupon feature coming soon!', 'success');
        }

        // Update cart count on page load
        document.addEventListener('DOMContentLoaded', function() {
            const cartCountElement = document.querySelector('.cart-count');
            if (cartCountElement) {
                cartCountElement.style.display = <?php echo $cart_count > 0 ? 'block' : 'none'; ?>;
            }
        });
    </script>
</body>
</html>
