<?php
require_once 'config/db.php';
requireLogin();

// Initialize variables
$cart_items = [];
$total = 0;
$error = '';
$success = '';

// Check if cart has items
if (!empty($_SESSION['cart'])) {
    $product_ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($product_ids), '?'));

    // Prepare and execute query to get cart items
    $query = "SELECT * FROM products WHERE id IN ($placeholders)";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        if (!empty($product_ids)) {
            $types = str_repeat('i', count($product_ids));
            $stmt->bind_param($types, ...$product_ids);
        }
        $stmt->execute();
        $result = $stmt->get_result();

        while ($product = $result->fetch_assoc()) {
            $quantity = $_SESSION['cart'][$product['id']];
            $subtotal = $product['price'] * $quantity;
            $total += $subtotal;

            $cart_items[] = [
                'product' => $product,
                'quantity' => $quantity,
                'subtotal' => $subtotal
            ];
        }
        $stmt->close();
    }
}

// Redirect if cart is empty
if (empty($cart_items)) {
    header('Location: shop.php');
    exit();
}

// Fetch user info
$user_id = $_SESSION['user_id'];
$user_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user = $user_stmt->get_result()->fetch_assoc();
$user_stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request';
    } else {
        // Get and sanitize form data
        $shipping_name = sanitize($_POST['name'] ?? '');
        $shipping_email = sanitize($_POST['email'] ?? '');
        $shipping_phone = sanitize($_POST['phone'] ?? '');
        $shipping_address = sanitize($_POST['address'] ?? '');
        $shipping_city = sanitize($_POST['city'] ?? '');
        $shipping_state = sanitize($_POST['state'] ?? '');
        $shipping_zip = sanitize($_POST['zip'] ?? '');
        $payment_method = sanitize($_POST['payment_method'] ?? 'COD');

        // Validate required fields
        if (!$shipping_name || !$shipping_email || !$shipping_phone || !$shipping_address || !$shipping_city || !$shipping_state || !$shipping_zip) {
            $error = 'Please fill in all required fields';
        } else {
            // Start transaction
            $conn->begin_transaction();

            try {
                // Create order - FIXED: Properly structured the bind_param call
                $order_stmt = $conn->prepare("INSERT INTO orders (
                    user_id, total_amount, discount_amount, final_amount,
                    shipping_name, shipping_email, shipping_phone, shipping_address,
                    shipping_city, shipping_state, shipping_zip, payment_method, status
                ) VALUES (?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");

                // Bind parameters - 12 parameters total
                // i (user_id), d (total), d (total), s (name), s (email), s (phone),
                // s (address), s (city), s (state), s (zip), s (payment_method)
                $order_stmt->bind_param(
                    "iddssssssss",
                    $user_id,
                    $total,
                    $total,
                    $shipping_name,
                    $shipping_email,
                    $shipping_phone,
                    $shipping_address,
                    $shipping_city,
                    $shipping_state,
                    $shipping_zip,
                    $payment_method
                );

                $order_stmt->execute();
                $order_id = $conn->insert_id;
                $order_stmt->close();

                // Add order items and update stock
                foreach ($cart_items as $item) {
                    $product_id = $item['product']['id'];
                    $quantity = $item['quantity'];
                    $price = $item['product']['price'];

                    // Insert order item
                    $item_stmt = $conn->prepare("INSERT INTO order_items (
                        order_id, product_id, quantity, price
                    ) VALUES (?, ?, ?, ?)");
                    $item_stmt->bind_param("iiid", $order_id, $product_id, $quantity, $price);
                    $item_stmt->execute();
                    $item_stmt->close();

                    // Update product stock
                    $stock_stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                    $stock_stmt->bind_param("ii", $quantity, $product_id);
                    $stock_stmt->execute();
                    $stock_stmt->close();
                }

                // Commit transaction
                $conn->commit();

                // Clear cart
                $_SESSION['cart'] = [];

                // Redirect to success page
                header("Location: order-success.php?order_id=$order_id");
                exit();

            } catch (Exception $e) {
                $conn->rollback();
                $error = 'Failed to place order. Please try again. Error: ' . $e->getMessage();
                error_log("Order placement error: " . $e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - YARNIFY</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Checkout Page Specific Styles */
        .checkout-container {
            max-width: 1200px;
            margin: 120px auto 3rem;
            padding: 0 5%;
        }

        .checkout-header {
            text-align: center;
            margin-bottom: 3rem;
        }

        .checkout-header h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--deep-rose);
            font-family: 'Playfair Display', serif;
        }

        .checkout-steps {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .step {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-light);
            font-family: 'Poppins', sans-serif;
        }

        .step.active {
            color: var(--deep-rose);
            font-weight: 600;
        }

        .step-number {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: var(--soft-pink);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: var(--text-dark);
        }

        .step.active .step-number {
            background: var(--deep-rose);
            color: white;
        }

        .checkout-grid {
            display: grid;
            grid-template-columns: 1.5fr 1fr;
            gap: 3rem;
        }

        .checkout-form {
            background: white;
            padding: 3rem;
            border-radius: 30px;
            box-shadow: var(--shadow-soft);
        }

        .form-section {
            margin-bottom: 3rem;
        }

        .form-section h2 {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            color: var(--deep-rose);
            font-family: 'Playfair Display', serif;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--text-dark);
            font-family: 'Poppins', sans-serif;
        }

        .form-input {
            width: 100%;
            padding: 1rem 1.5rem;
            border: 2px solid var(--soft-pink);
            border-radius: 25px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: all 0.4s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--deep-rose);
            box-shadow: 0 0 0 3px rgba(216, 93, 122, 0.2);
        }

        .payment-options {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .payment-option {
            padding: 1.5rem;
            border: 2px solid var(--soft-pink);
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.4s ease;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .payment-option:hover {
            border-color: var(--deep-rose);
        }

        .payment-option.selected {
            border-color: var(--deep-rose);
            background: var(--light-pink);
        }

        .payment-option input[type="radio"] {
            width: 20px;
            height: 20px;
            accent-color: var(--deep-rose);
        }

        .order-summary-checkout {
            background: white;
            padding: 2.5rem;
            border-radius: 30px;
            box-shadow: var(--shadow-soft);
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        .order-summary-checkout h2 {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            color: var(--deep-rose);
            font-family: 'Playfair Display', serif;
        }

        .order-item {
            display: flex;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 1px solid var(--soft-pink);
        }

        .order-item-image {
            width: 70px;
            height: 70px;
            border-radius: 15px;
            overflow: hidden;
            background: var(--soft-pink);
        }

        .order-item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .order-item-info {
            flex: 1;
        }

        .order-item-name {
            font-weight: 600;
            margin-bottom: 0.3rem;
            font-family: 'Poppins', sans-serif;
        }

        .order-item-qty {
            color: var(--text-light);
            font-size: 0.9rem;
            font-family: 'Poppins', sans-serif;
        }

        .order-item-price {
            font-weight: 700;
            color: var(--deep-rose);
            font-family: 'Poppins', sans-serif;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 1rem 0;
            font-family: 'Poppins', sans-serif;
        }

        .summary-row.total {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--deep-rose);
            border-top: 2px solid var(--soft-pink);
            margin-top: 1rem;
            padding-top: 1.5rem;
        }

        .place-order-btn {
            width: 100%;
            padding: 1.5rem;
            background: var(--deep-rose);
            color: white;
            border: none;
            border-radius: 30px;
            font-size: 1.2rem;
            font-weight: 700;
            margin-top: 2rem;
            box-shadow: var(--shadow-medium);
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        .place-order-btn:hover {
            box-shadow: var(--glow-pink);
            transform: translateY(-3px);
        }

        .secure-checkout {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 1rem;
            color: var(--text-light);
            font-size: 0.9rem;
            font-family: 'Poppins', sans-serif;
        }

        .alert-error {
            margin-bottom: 2rem;
            padding: 1rem;
            background: #FFE4E9;
            color: #D85D7A;
            border-radius: 15px;
            text-align: center;
            font-family: 'Poppins', sans-serif;
        }

        @media (max-width: 968px) {
            .checkout-grid {
                grid-template-columns: 1fr;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .order-summary-checkout {
                position: relative;
                top: 0;
            }
        }
    </style>
    <link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>

        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>

        <div class="nav-right">
            <a href="<?php echo isLoggedIn() ? 'wishlist.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <?php if(isLoggedIn()): ?>
                    <span class="wishlist-count" style="display: <?php echo isset($_SESSION['wishlist_count']) && $_SESSION['wishlist_count'] > 0 ? 'block' : 'none'; ?>;">
                        <?php echo isset($_SESSION['wishlist_count']) ? $_SESSION['wishlist_count'] : '0'; ?>
                    </span>
                <?php endif; ?>
            </a>
            <a href="<?php echo isLoggedIn() ? 'cart.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
                <?php if(isLoggedIn()): ?>
                    <span class="cart-count" style="display: <?php echo !empty($cart_items) ? 'block' : 'none'; ?>;">
                        <?php echo count($cart_items); ?>
                    </span>
                <?php endif; ?>
            </a>
            <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
    </nav>

    <div class="checkout-container">
        <div class="checkout-header">
            <h1>Checkout</h1>
            <div class="checkout-steps">
                <div class="step">
                    <span class="step-number">1</span>
                    <span>Cart</span>
                </div>
                <span style="color: var(--soft-pink);">→</span>
                <div class="step active">
                    <span class="step-number">2</span>
                    <span>Checkout</span>
                </div>
                <span style="color: var(--soft-pink);">→</span>
                <div class="step">
                    <span class="step-number">3</span>
                    <span>Complete</span>
                </div>
            </div>
        </div>

        <?php if ($error): ?>
        <div class="alert-error">
            <?php echo $error; ?>
        </div>
        <?php endif; ?>

        <div class="checkout-grid">
            <div class="checkout-form">
                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">

                    <!-- Shipping Information -->
                    <div class="form-section">
                        <h2>Shipping Information</h2>

                        <div class="form-group">
                            <label for="name">Full Name *</label>
                            <input type="text" id="name" name="name" class="form-input" required
                                   value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>">
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" class="form-input" required
                                       value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>">
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone Number *</label>
                                <input type="tel" id="phone" name="phone" class="form-input" required
                                       value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="address">Street Address *</label>
                            <input type="text" id="address" name="address" class="form-input" required
                                   placeholder="123 Main Street, Apt 4">
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="city">City *</label>
                                <input type="text" id="city" name="city" class="form-input" required>
                            </div>

                            <div class="form-group">
                                <label for="state">State/Province *</label>
                                <input type="text" id="state" name="state" class="form-input" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="zip">ZIP / Postal Code *</label>
                            <input type="text" id="zip" name="zip" class="form-input" required>
                        </div>
                    </div>

                    <!-- Payment Method -->
                    <div class="form-section">
                        <h2>Payment Method</h2>

                        <div class="payment-options">
                            <label class="payment-option selected">
                                <input type="radio" name="payment_method" value="COD" checked>
                                <div>
                                    <div style="font-weight: 600; margin-bottom: 0.3rem;">💵 Cash on Delivery</div>
                                    <div style="font-size: 0.9rem; color: var(--text-light);">Pay when you receive your order</div>
                                </div>
                            </label>

                            <label class="payment-option">
                                <input type="radio" name="payment_method" value="Card" disabled>
                                <div>
                                    <div style="font-weight: 600; margin-bottom: 0.3rem;">💳 Credit / Debit Card</div>
                                    <div style="font-size: 0.9rem; color: var(--text-light);">Coming soon</div>
                                </div>
                            </label>

                            <label class="payment-option">
                                <input type="radio" name="payment_method" value="UPI" disabled>
                                <div>
                                    <div style="font-weight: 600; margin-bottom: 0.3rem;">📱 UPI / Digital Wallet</div>
                                    <div style="font-size: 0.9rem; color: var(--text-light);">Coming soon</div>
                                </div>
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="place-order-btn">Place Order</button>

                    <div class="secure-checkout">
                        🔒 Secure Checkout - Your information is safe with us
                    </div>
                </form>
            </div>

            <!-- Order Summary -->
            <div class="order-summary-checkout">
                <h2>Order Summary</h2>

                <?php foreach ($cart_items as $item): ?>
                <div class="order-item">
                    <div class="order-item-image">
                        <img src="assets/images/products/<?php echo $item['product']['image']; ?>"
                             alt="<?php echo htmlspecialchars($item['product']['name']); ?>">
                    </div>
                    <div class="order-item-info">
                        <div class="order-item-name"><?php echo htmlspecialchars($item['product']['name']); ?></div>
                        <div class="order-item-qty">Qty: <?php echo $item['quantity']; ?></div>
                    </div>
                    <div class="order-item-price">
                        ₹<?php echo number_format($item['subtotal'], 2); ?>
                    </div>
                </div>
                <?php endforeach; ?>

                <div class="summary-row" style="border-top: 1px solid var(--soft-pink); margin-top: 1rem; padding-top: 1rem;">
                    <span>Subtotal:</span>
                    <span>₹<?php echo number_format($total, 2); ?></span>
                </div>

                <div class="summary-row">
                    <span>Shipping:</span>
                    <span style="color: #2E7D32; font-weight: 600;">FREE</span>
                </div>

                <div class="summary-row">
                    <span>Tax:</span>
                    <span>₹0.00</span>
                </div>

                <div class="summary-row total">
                    <span>Total:</span>
                    <span>₹<?php echo number_format($total, 2); ?></span>
                </div>

                <div style="background: var(--light-pink); padding: 1.5rem; border-radius: 15px; margin-top: 2rem; text-align: center;">
                    <div style="font-weight: 600; margin-bottom: 0.5rem;">🎁 Free Gift Packaging</div>
                    <div style="font-size: 0.9rem; color: var(--text-light);">Every order comes beautifully wrapped</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care. Each item is unique and crafted to bring joy to your life.</p>
                <p>Yarnify is a handmade crochet brand offering affordable and customizable accessories crafted with love.</p>
                <div class="social-links">
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-9-9 9 9 0 0 1 9-9c2.5 0 4.8.9 6.5 2.4"/>
                            <path d="M16 8h-2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v-4h-1"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <path d="M22 6l-10 7L2 6"/>
                        </svg>
                    </a>
                </div>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="shop.php">Shop</a>
                <a href="collections.php">Collections</a>
                <a href="about.php">About</a>
                <a href="reviews.php">Reviews</a>
            </div>
            <div class="footer-section">
                <h3>Customer Care</h3>
                <a href="#">Shipping Info</a>
                <a href="#">Returns</a>
                <a href="#">FAQ</a>
                <a href="#">Contact Us</a>
            </div>
            <div class="footer-section">
                <h3>Newsletter</h3>
                <p>Subscribe for exclusive offers and updates!</p>
                <form class="newsletter-form">
                    <input type="email" class="newsletter-input" placeholder="Your email">
                    <button type="submit" class="join-btn">Join</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 YARNIFY. Made with 💖 | All Rights Reserved</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
    <script>
        // Payment option selection
        document.querySelectorAll('.payment-option').forEach(option => {
            option.addEventListener('click', function() {
                // Only allow selection if the payment method is available
                if (!this.querySelector('input[type="radio"]').disabled) {
                    document.querySelectorAll('.payment-option').forEach(opt => {
                        opt.classList.remove('selected');
                    });
                    this.classList.add('selected');
                    this.querySelector('input[type="radio"]').checked = true;
                }
            });
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = '#F44336';
                } else {
                    field.style.borderColor = '';
                }
            });

            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
    </script>
</body>
</html>
