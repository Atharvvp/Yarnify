<?php
require_once 'config/db.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$response = ['success' => false, 'message' => 'An error occurred'];

try {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';

        if ($action === 'add') {
            $product_id = (int)($_POST['product_id'] ?? 0);
            $quantity = (int)($_POST['quantity'] ?? 1);

            if ($product_id > 0 && $quantity > 0) {
                // Check product existence and stock
                $stmt = $conn->prepare("SELECT id, name, price, stock FROM products WHERE id = ? AND stock > 0");
                $stmt->bind_param("i", $product_id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($product = $result->fetch_assoc()) {
                    $current_qty = $_SESSION['cart'][$product_id] ?? 0;
                    $new_qty = $current_qty + $quantity;

                    if ($new_qty <= $product['stock']) {
                        $_SESSION['cart'][$product_id] = $new_qty;
                        $response['success'] = true;
                        $response['message'] = 'Added to cart successfully!';
                        $response['cart_count'] = array_sum($_SESSION['cart']);
                    } else {
                        $response['message'] = 'Insufficient stock. Only ' . $product['stock'] . ' items available.';
                    }
                } else {
                    $response['message'] = 'Product not found or out of stock';
                }
                $stmt->close();
            }

        } elseif ($action === 'update') {
            $product_id = (int)($_POST['product_id'] ?? 0);
            $quantity = (int)($_POST['quantity'] ?? 0);

            if ($product_id > 0) {
                if ($quantity > 0) {
                    $_SESSION['cart'][$product_id] = $quantity;
                    $response['success'] = true;
                    $response['message'] = 'Cart updated';
                    $response['cart_count'] = array_sum($_SESSION['cart']);
                } else {
                    unset($_SESSION['cart'][$product_id]);
                    $response['success'] = true;
                    $response['message'] = 'Item removed from cart';
                    $response['cart_count'] = array_sum($_SESSION['cart']);
                }
            }

        } elseif ($action === 'remove') {
            $product_id = (int)($_POST['product_id'] ?? 0);

            if ($product_id > 0 && isset($_SESSION['cart'][$product_id])) {
                unset($_SESSION['cart'][$product_id]);
                $response['success'] = true;
                $response['message'] = 'Item removed from cart';
                $response['cart_count'] = array_sum($_SESSION['cart']);
            }

        } elseif ($action === 'clear') {
            $_SESSION['cart'] = [];
            $response['success'] = true;
            $response['message'] = 'Cart cleared';
            $response['cart_count'] = 0;
        }

    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? '';

        if ($action === 'count') {
            $count = array_sum($_SESSION['cart']);
            $response['success'] = true;
            $response['count'] = $count;

        } elseif ($action === 'items') {
            $items = [];
            if (!empty($_SESSION['cart'])) {
                $product_ids = array_keys($_SESSION['cart']);
                $placeholders = str_repeat('?,', count($product_ids) - 1) . '?';
                $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
                $stmt->bind_param(str_repeat('i', count($product_ids)), ...$product_ids);
                $stmt->execute();
                $result = $stmt->get_result();

                while ($product = $result->fetch_assoc()) {
                    $product['quantity'] = $_SESSION['cart'][$product['id']];
                    $product['subtotal'] = $product['price'] * $product['quantity'];
                    $items[] = $product;
                }
                $stmt->close();
            }

            $response['success'] = true;
            $response['items'] = $items;
            $response['total'] = array_sum(array_column($items, 'subtotal'));
        }
    }

} catch (Exception $e) {
    $response['message'] = 'Server error: ' . $e->getMessage();
    error_log('Cart handler error: ' . $e->getMessage());
}

echo json_encode($response);
?>