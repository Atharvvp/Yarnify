<?php
require_once '../config/db.php';
requireAdmin();

// Fetch statistics
$total_sales_query = "SELECT SUM(final_amount) as total FROM orders WHERE status != 'cancelled'";
$total_sales = $conn->query($total_sales_query)->fetch_assoc()['total'] ?? 0;

$total_orders_query = "SELECT COUNT(*) as count FROM orders";
$total_orders = $conn->query($total_orders_query)->fetch_assoc()['count'] ?? 0;

$total_users_query = "SELECT COUNT(*) as count FROM users WHERE role = 'customer'";
$total_users = $conn->query($total_users_query)->fetch_assoc()['count'] ?? 0;

$total_products_query = "SELECT COUNT(*) as count FROM products";
$total_products = $conn->query($total_products_query)->fetch_assoc()['count'] ?? 0;

$recent_orders_query = "SELECT o.*, u.name as customer_name FROM orders o 
                        JOIN users u ON o.user_id = u.id 
                        ORDER BY o.created_at DESC LIMIT 10";
$recent_orders = $conn->query($recent_orders_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - YARNIFY</title>
    <link rel="stylesheet" href="style.css">
    <style>
        :root {
            --admin-primary: #B8425A;
            --admin-secondary: #D85D7A;
            --admin-bg: #FFF5F7;
        }
        
        .admin-layout {
            display: flex;
            min-height: 100vh;
        }
        
        .admin-sidebar {
            width: 250px;
            background: var(--admin-primary);
            color: white;
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .admin-brand {
            text-align: center;
            padding: 0 1.5rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            margin-bottom: 2rem;
        }
        
        .admin-brand h2 {
            color: white;
            font-size: 1.5rem;
            margin-bottom: 0.3rem;
        }
        
        .admin-brand p {
            font-size: 0.85rem;
            opacity: 0.8;
        }
        
        .admin-menu {
            list-style: none;
        }
        
        .admin-menu-item {
            margin: 0.5rem 0;
        }
        
        .admin-menu-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem 1.5rem;
            color: white;
            transition: all 0.3s ease;
        }
        
        .admin-menu-link:hover,
        .admin-menu-link.active {
            background: var(--admin-secondary);
            border-left: 4px solid white;
        }
        
        .admin-content {
            margin-left: 250px;
            flex: 1;
            background: var(--admin-bg);
            padding: 2rem;
        }
        
        .admin-header {
            background: white;
            padding: 1.5rem 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow-soft);
        }
        
        .admin-header h1 {
            color: var(--admin-primary);
            font-size: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            padding: 2rem;
            border-radius: 20px;
            box-shadow: var(--shadow-soft);
            transition: all 0.4s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-medium);
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            background: var(--gradient-pink);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
            font-size: 1.5rem;
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--admin-primary);
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            color: var(--text-light);
            font-size: 0.95rem;
        }
        
        .table-card {
            background: white;
            padding: 2rem;
            border-radius: 20px;
            box-shadow: var(--shadow-soft);
        }
        
        .table-card h2 {
            color: var(--admin-primary);
            margin-bottom: 1.5rem;
        }
        
        .admin-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .admin-table thead {
            background: var(--soft-pink);
        }
        
        .admin-table th {
            padding: 1rem;
            text-align: left;
            color: var(--admin-primary);
            font-weight: 600;
        }
        
        .admin-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--soft-pink);
        }
        
        .admin-table tbody tr:hover {
            background: var(--light-pink);
        }
        
        .status-badge {
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .status-pending {
            background: #FFF3E0;
            color: #F57C00;
        }
        
        .status-processing {
            background: #E3F2FD;
            color: #1976D2;
        }
        
        .status-shipped {
            background: #F3E5F5;
            color: #7B1FA2;
        }
        
        .status-delivered {
            background: #E8F5E9;
            color: #2E7D32;
        }
        
        .status-cancelled {
            background: #FFEBEE;
            color: #C62828;
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="admin-brand">
                <h2>YARNIFY</h2>
                <p>Admin Panel</p>
            </div>
            
            <ul class="admin-menu">
                <li class="admin-menu-item">
                    <a href="/dashboard.php" class="admin-menu-link active">
                        📊 Dashboard
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="products.php" class="admin-menu-link">
                        🧶 Products
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="add-product.php" class="admin-menu-link">
                        ➕ Add Product
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="orders.php" class="admin-menu-link">
                        📦 Orders
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="customers.php" class="admin-menu-link">
                        👥 Customers
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="reviews.php" class="admin-menu-link">
                        ⭐ Reviews
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="index.php" class="admin-menu-link">
                        🏠 View Store
                    </a>
                </li>
                <li class="admin-menu-item">
                    <a href="logout.php" class="admin-menu-link">
                        🚪 Logout
                    </a>
                </li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="admin-content">
            <div class="admin-header">
                <h1>Dashboard</h1>
                <div>
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</span>
                </div>
            </div>

            <!-- Statistics Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-value">$<?php echo number_format($total_sales, 2); ?></div>
                    <div class="stat-label">Total Sales</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">📦</div>
                    <div class="stat-value"><?php echo $total_orders; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value"><?php echo $total_users; ?></div>
                    <div class="stat-label">Total Customers</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">🧶</div>
                    <div class="stat-value"><?php echo $total_products; ?></div>
                    <div class="stat-label">Total Products</div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="table-card">
                <h2>Recent Orders</h2>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($order = $recent_orders->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                            <td>$<?php echo number_format($order['final_amount'], 2); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $order['status']; ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                            <td>
                                <a href="orders.php?id=<?php echo $order['id']; ?>" style="color: var(--deep-rose);">View</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
