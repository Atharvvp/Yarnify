<?php
require_once '../config/db.php';
requireAdmin();

// Fetch all customers
$customers = $conn->query("
    SELECT
        u.*,
        COUNT(o.id) as total_orders,
        COALESCE(SUM(o.final_amount), 0) as total_spent
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    WHERE u.role = 'customer'
    GROUP BY u.id
    ORDER BY u.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers Management - Admin</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="admin-style.css">
    <style>
        :root {
            --deep-rose: #D85D7A;
            --soft-pink: #FFE4E9;
            --light-pink: #FFF0F5;
            --text-dark: #333;
            --text-light: #666;
            --border-color: #E9E9E9;
            --focus-glow: rgba(216, 93, 122, 0.3);
            --status-active: #d4edda;
            --status-inactive: #f8d7da;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--light-pink);
        }

        .admin-header h1 {
            color: var(--deep-rose);
            font-size: 1.8rem;
            margin-bottom: 1rem;
        }

        .table-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
            padding: 2rem;
            margin: 1.5rem 0;
            border: 1px solid var(--border-color);
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }

        .admin-table th {
            background: var(--soft-pink);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-dark);
            border-bottom: 2px solid var(--border-color);
        }

        .admin-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
        }

        .admin-table tr:hover {
            background: rgba(216, 93, 122, 0.03);
        }

        .status-badge {
            padding: 0.5rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            text-align: center;
            display: inline-block;
        }

        .status-active {
            background: var(--status-active);
            color: #155724;
        }

        .status-inactive {
            background: var(--status-inactive);
            color: #721c24;
        }

        @media (max-width: 768px) {
            .admin-table {
                font-size: 0.85rem;
            }

            .admin-table th,
            .admin-table td {
                padding: 0.7rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <?php include 'sidebar.php'; ?>

        <main class="admin-content">
            <div class="admin-header">
                <h1>Customers Management</h1>
            </div>

            <div class="table-card">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Total Orders</th>
                            <th>Total Spent</th>
                            <th>Joined</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($customer = $customers->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $customer['id']; ?></td>
                            <td><?php echo htmlspecialchars($customer['name']); ?></td>
                            <td><?php echo htmlspecialchars($customer['email']); ?></td>
                            <td><?php echo htmlspecialchars($customer['phone'] ?? 'N/A'); ?></td>
                            <td><?php echo $customer['total_orders']; ?></td>
                            <td>$<?php echo number_format($customer['total_spent'], 2); ?></td>
                            <td><?php echo date('M d, Y', strtotime($customer['created_at'])); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $customer['status'] == 'active' ? 'active' : 'inactive'; ?>">
                                    <?php echo ucfirst($customer['status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
