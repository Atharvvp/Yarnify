<?php
require_once '../config/db.php';
requireAdmin();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $category = sanitize($_POST['category'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $is_trending = isset($_POST['is_trending']) ? 1 : 0;
    $is_bestseller = isset($_POST['is_bestseller']) ? 1 : 0;

    // Handle single image upload
    if (isset($_FILES['images']) && $_FILES['images']['error'][0] === UPLOAD_ERR_OK) {
        $uploadDir = '../assets/images/products/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $imageTmpName = $_FILES['images']['tmp_name'][0];
        $imageName = basename($_FILES['images']['name'][0]);
        $targetFilePath = $uploadDir . $imageName;

        if (move_uploaded_file($imageTmpName, $targetFilePath)) {
            $image = $imageName;
        } else {
            $error = 'Failed to upload image';
        }
    } else {
        $image = 'placeholder.jpg'; // Default image if none uploaded
    }

    if (!$name || !$category || !$price) {
        $error = 'Please fill in all required fields';
    } else {
        $stmt = $conn->prepare("INSERT INTO products (name, description, category, price, stock, image, is_trending, is_bestseller) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdisii", $name, $description, $category, $price, $stock, $image, $is_trending, $is_bestseller);

        if ($stmt->execute()) {
            header('Location: products.php?msg=added');
            exit();
        } else {
            $error = 'Failed to add product: ' . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Admin</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="admin-style.css">
    <style>
        :root {
            --deep-rose: #D85D7A;
            --soft-pink: #FFE4E9;
            --light-pink: #FFF0F5;
            --text-dark: #333;
            --text-light: #666;
            --border-color: #E9E9E9;
            --focus-glow: rgba(216, 93, 122, 0.3);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--light-pink);
        }

        .profile-section {
            background: white;
            border-radius: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
            padding: 2.5rem;
            margin: 1.5rem 0;
            border: 1px solid var(--border-color);
        }

        .form-group {
            margin-bottom: 1.8rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.6rem;
            font-weight: 600;
            color: var(--text-dark);
        }

        .form-input {
            width: 100%;
            padding: 0.9rem 1.2rem;
            border: 1px solid var(--border-color);
            border-radius: 10px;
            font-size: 1rem;
            background: var(--soft-pink);
            transition: all 0.3s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--deep-rose);
            box-shadow: 0 0 0 3px var(--focus-glow);
        }

        textarea.form-input {
            resize: vertical;
            min-height: 120px;
            padding: 1rem 1.2rem;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.8rem;
        }

        .checkbox-group {
            display: flex;
            gap: 2rem;
            margin: 1.8rem 0;
        }

        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            font-weight: 500;
            cursor: pointer;
            color: var(--text-dark);
        }

        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: var(--deep-rose);
        }

        .btn-primary {
            background: var(--deep-rose);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: block;
            margin: 2rem auto 0;
        }

        .btn-primary:hover {
            background: #B03052;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: var(--soft-pink);
            color: var(--deep-rose);
            border: 1px solid var(--border-color);
            padding: 0.7rem 1.4rem;
            border-radius: 10px;
            font-size: 0.95rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-secondary:hover {
            background: #FFC0CB;
            transform: translateY(-1px);
        }

        .alert {
            padding: 1.2rem;
            border-radius: 10px;
            margin-bottom: 1.8rem;
            background: #FFE4E9;
            color: var(--deep-rose);
            border: 1px solid #FFC0CB;
        }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.8rem;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }

            .checkbox-group {
                flex-direction: column;
                gap: 1rem;
            }

            .profile-section {
                padding: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <?php include 'sidebar.php'; ?>

        <main class="admin-content">
            <div class="admin-header">
                <h1>Add New Product</h1>
                <a href="products.php" class="btn-secondary">← Back to Products</a>
            </div>

            <?php if ($error): ?>
            <div class="alert"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="profile-section">
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">Product Name *</label>
                        <input type="text" id="name" name="name" class="form-input" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" class="form-input" rows="4"></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="category">Category *</label>
                            <select id="category" name="category" class="form-input" required>
                                <option value="">Select Category</option>
                                <option value="bags">Bags</option>
                                <option value="tops">Tops</option>
                                <option value="accessories">Accessories</option>
                                <option value="plushies">Plushies</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="price">Price *</label>
                            <input type="number" id="price" name="price" step="0.01" class="form-input" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="stock">Stock Quantity</label>
                        <input type="number" id="stock" name="stock" class="form-input" value="0">
                    </div>

                    <div class="form-group">
                        <label for="images">Product Image</label>
                        <input type="file" id="images" name="images[]" class="form-input" accept="image/*">
                    </div>

                    <div class="checkbox-group">
                        <label>
                            <input type="checkbox" name="is_trending">
                            <span>Mark as Trending</span>
                        </label>

                        <label>
                            <input type="checkbox" name="is_bestseller">
                            <span>Mark as Bestseller</span>
                        </label>
                    </div>

                    <button type="submit" class="btn-primary">Add Product</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>