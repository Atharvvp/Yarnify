<?php
require_once '../config/db.php';
requireAdmin();

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header('Location: products.php?msg=deleted');
    exit();
}

// Fetch all products
$products = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products Management - Admin</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="admin-style.css">
    <style>
        :root {
            --deep-rose: #D85D7A;
            --soft-pink: #FFE4E9;
            --light-pink: #FFF0F5;
            --text-dark: #333;
            --text-light: #666;
            --border-color: #E9E9E9;
            --focus-glow: rgba(216, 93, 122, 0.3);
            --status-trending: #FFD700;
            --status-bestseller: #d4edda;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--light-pink);
        }

        .admin-header h1 {
            color: var(--deep-rose);
            font-size: 1.8rem;
            margin-bottom: 1rem;
        }

        .table-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
            padding: 2rem;
            margin: 1.5rem 0;
            border: 1px solid var(--border-color);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .table-header h2 {
            color: var(--deep-rose);
            font-size: 1.4rem;
            margin: 0;
        }

        .btn-primary {
            background: var(--deep-rose);
            color: white;
            border: none;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: #B03052;
            transform: translateY(-1px);
        }

        .alert {
            padding: 1.2rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            background: var(--status-bestseller);
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }

        .admin-table th {
            background: var(--soft-pink);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-dark);
            border-bottom: 2px solid var(--border-color);
        }

        .admin-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
        }

        .admin-table tr:hover {
            background: rgba(216, 93, 122, 0.03);
        }

        .status-badge {
            padding: 0.5rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            text-align: center;
            display: inline-block;
            margin-right: 0.3rem;
            margin-bottom: 0.3rem;
        }

        .status-trending {
            background: var(--status-trending);
            color: var(--text-dark);
        }

        .status-bestseller {
            background: var(--status-bestseller);
            color: #155724;
        }

        .action-link {
            color: var(--deep-rose);
            text-decoration: none;
            font-weight: 600;
            margin-right: 1rem;
            transition: color 0.3s ease;
        }

        .action-link:hover {
            color: #B03052;
            text-decoration: underline;
        }

        .delete-link {
            color: #C62828;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .delete-link:hover {
            color: #8B0000;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .admin-table {
                font-size: 0.85rem;
            }

            .admin-table th,
            .admin-table td {
                padding: 0.7rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <?php include 'sidebar.php'; ?>

        <main class="admin-content">
            <div class="admin-header">
                <h1>Products Management</h1>
            </div>

            <?php if (isset($_GET['msg'])): ?>
            <div class="alert">Product <?php echo htmlspecialchars($_GET['msg']); ?> successfully!</div>
            <?php endif; ?>

            <div class="table-card">
                <div class="table-header">
                    <h2>All Products</h2>
                    <a href="add-product.php"><button class="btn-primary">Add New Product</button></a>
                </div>

                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($product = $products->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $product['id']; ?></td>
                            <td>
                                <img src="assets/images/products/<?php echo htmlspecialchars($product['image']); ?>"
                                     style="width: 50px; height: 50px; border-radius: 10px; object-fit: cover;"
                                     alt="<?php echo htmlspecialchars($product['name']); ?>">
                            </td>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($product['category'])); ?></td>
                            <td>$<?php echo number_format($product['price'], 2); ?></td>
                            <td><?php echo $product['stock']; ?></td>
                            <td>
                                <?php if ($product['is_trending']): ?>
                                <span class="status-badge status-trending">Trending</span>
                                <?php endif; ?>
                                <?php if ($product['is_bestseller']): ?>
                                <span class="status-badge status-bestseller">Bestseller</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="edit-product.php?id=<?php echo $product['id']; ?>" class="action-link">Edit</a>
                                <a href="?delete=<?php echo $product['id']; ?>" onclick="return confirm('Delete this product?')" class="delete-link">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
