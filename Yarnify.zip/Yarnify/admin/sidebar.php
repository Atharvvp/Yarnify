<aside class="admin-sidebar">
    <div class="admin-brand">
        <h2>YARNIFY</h2>
        <p>Admin Panel</p>
    </div>
    
    <ul class="admin-menu">
        <li class="admin-menu-item">
            <a href="dashboard.php" class="admin-menu-link">📊 Dashboard</a>
        </li>
        <li class="admin-menu-item">
            <a href="products.php" class="admin-menu-link">🧶 Products</a>
        </li>
        <li class="admin-menu-item">
            <a href="add-product.php" class="admin-menu-link">➕ Add Product</a>
        </li>
        <li class="admin-menu-item">
            <a href="orders.php" class="admin-menu-link">📦 Orders</a>
        </li>
        <li class="admin-menu-item">
            <a href="customers.php" class="admin-menu-link">👥 Customers</a>
        </li>
        <li class="admin-menu-item">
            <a href="../reviews.php" class="admin-menu-link">⭐ Reviews</a>
        </li>
        <li class="admin-menu-item">
            <a href="../index.php" class="admin-menu-link">🏠 View Store</a>
        </li>
        <li class="admin-menu-item">
            <a href="../logout.php" class="admin-menu-link">🚪 Logout</a>
        </li>
    </ul>
</aside>
