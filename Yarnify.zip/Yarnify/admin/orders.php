<?php
require_once '../config/db.php';
requireAdmin();

// Handle status update
if (isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $status = sanitize($_POST['status']);
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();
}

// Fetch all orders
$orders = $conn->query("SELECT o.*, u.name as customer_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - Admin</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="admin-style.css">
    <style>
        :root {
            --deep-rose: #D85D7A;
            --soft-pink: #FFE4E9;
            --light-pink: #FFF0F5;
            --text-dark: #333;
            --text-light: #666;
            --border-color: #E9E9E9;
            --focus-glow: rgba(216, 93, 122, 0.3);
            --status-pending: #FFD700;
            --status-processing: #1976D2;
            --status-shipped: #7B1FA2;
            --status-delivered: #2E7D32;
            --status-cancelled: #C62828;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--light-pink);
        }

        .table-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.05);
            padding: 2rem;
            margin: 1.5rem 0;
            border: 1px solid var(--border-color);
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.95rem;
        }

        .admin-table th {
            background: var(--soft-pink);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-dark);
            border-bottom: 2px solid var(--border-color);
        }

        .admin-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
        }

        .admin-table tr:hover {
            background: rgba(216, 93, 122, 0.03);
        }

        .status-badge {
            padding: 0.5rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            text-align: center;
            display: inline-block;
        }

        .status-pending {
            background: rgba(255, 215, 0, 0.15);
            color: var(--status-pending);
        }

        .status-processing {
            background: rgba(25, 118, 210, 0.15);
            color: var(--status-processing);
        }

        .status-shipped {
            background: rgba(123, 31, 162, 0.15);
            color: var(--status-shipped);
        }

        .status-delivered {
            background: rgba(46, 125, 50, 0.15);
            color: var(--status-delivered);
        }

        .status-cancelled {
            background: rgba(198, 40, 40, 0.15);
            color: var(--status-cancelled);
        }

        select[name="status"] {
            padding: 0.6rem 1rem;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            background: white;
            color: var(--text-dark);
            cursor: pointer;
            transition: border-color 0.3s ease;
        }

        select[name="status"]:focus {
            outline: none;
            border-color: var(--deep-rose);
            box-shadow: 0 0 0 2px var(--focus-glow);
        }

        .action-link {
            color: var(--deep-rose);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .action-link:hover {
            color: #B03052;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .admin-table {
                font-size: 0.85rem;
            }

            .admin-table th,
            .admin-table td {
                padding: 0.7rem;
            }
        }
    </style>
</head>
<body>
    <div class="admin-layout">
        <?php include 'sidebar.php'; ?>

        <main class="admin-content">
            <div class="admin-header">
                <h1>Orders Management</h1>
            </div>

            <div class="table-card">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($order = $orders->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                            <td>$<?php echo number_format($order['final_amount'], 2); ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <select name="status" onchange="this.form.submit()">
                                        <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="processing" <?php echo $order['status'] == 'processing' ? 'selected' : ''; ?>>Processing</option>
                                        <option value="shipped" <?php echo $order['status'] == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                                        <option value="delivered" <?php echo $order['status'] == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                        <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                            <td>
                                <a href="order-details.php?id=<?php echo $order['id']; ?>" class="action-link">View Details</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
