// ===== LUXURY CROCHET SHOP - MAIN JAVASCRIPT =====

// ===== SPLASH SCREEN =====
window.addEventListener('load', () => {
    setTimeout(() => {
        const splashScreen = document.querySelector('.splash-screen');
        if (splashScreen) {
            splashScreen.style.display = 'none';
        }
    }, 3500);
});

// ===== MOBILE MENU TOGGLE =====
const menuToggle = document.querySelector('.menu-toggle');
const navLeft = document.querySelector('.nav-left');
const navRight = document.querySelector('.nav-right');

if (menuToggle) {
    menuToggle.addEventListener('click', () => {
        navLeft.classList.toggle('active');
        navRight.classList.toggle('active');
    });
}

// ===== SCROLL REVEAL ANIMATION =====
const revealElements = document.querySelectorAll('.reveal');

const revealOnScroll = () => {
    revealElements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;

        if (elementTop < windowHeight - 100) {
            element.classList.add('active');
        }
    });
};

window.addEventListener('scroll', revealOnScroll);
window.addEventListener('load', revealOnScroll);

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ===== NAVBAR SCROLL EFFECT =====
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;

    if (currentScroll <= 0) {
        navbar.style.boxShadow = '0 4px 20px rgba(255, 192, 203, 0.15)';
    } else {
        navbar.style.boxShadow = '0 8px 30px rgba(255, 192, 203, 0.25)';
    }

    lastScroll = currentScroll;
});

// ===== TABS FUNCTIONALITY =====
const tabBtns = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const targetTab = btn.getAttribute('data-tab');

        // Remove active class from all buttons and contents
        tabBtns.forEach(b => b.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));

        // Add active class to clicked button and corresponding content
        btn.classList.add('active');
        const targetContent = document.querySelector(`#${targetTab}`);
        if (targetContent) {
            targetContent.classList.add('active');
        }
    });
});

// ===== ADD TO CART =====
function addToCart(productId, quantity = 1) {
    fetch('/cart-handler.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=add&product_id=${productId}&quantity=${quantity}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Product added to cart!', 'success');
            updateCartCount();
        } else {
            showNotification(data.message || 'Failed to add to cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Something went wrong', 'error');
    });
}

// ===== ADD TO WISHLIST =====
function addToWishlist(productId) {
    fetch('/wishlist-handler.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=add&product_id=${productId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Added to wishlist!', 'success');
            updateWishlistCount();
        } else {
            showNotification(data.message || 'Failed to add to wishlist', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Something went wrong', 'error');
    });
}

// ===== UPDATE CART COUNT =====
function updateCartCount() {
    fetch('/cart-handler.php?action=count')
        .then(response => response.json())
        .then(data => {
            const cartCount = document.querySelector('.cart-count');
            if (cartCount) {
                cartCount.textContent = data.count || 0;
                if (data.count > 0) {
                    cartCount.style.display = 'flex';
                } else {
                    cartCount.style.display = 'none';
                }
            }
        })
        .catch(error => console.error('Error:', error));
}

// ===== UPDATE WISHLIST COUNT =====
function updateWishlistCount() {
    fetch('/wishlist-handler.php?action=count')
        .then(response => response.json())
        .then(data => {
            const wishlistCount = document.querySelector('.wishlist-count');
            if (wishlistCount) {
                wishlistCount.textContent = data.count || 0;
                if (data.count > 0) {
                    wishlistCount.style.display = 'flex';
                } else {
                    wishlistCount.style.display = 'none';
                }
            }
        })
        .catch(error => console.error('Error:', error));
}

// ===== NOTIFICATION SYSTEM =====
function showNotification(message, type = 'success') {
    // Remove existing notifications
    const existingNotif = document.querySelector('.notification');
    if (existingNotif) {
        existingNotif.remove();
    }

    // Create notification
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${type === 'success' ? '✓' : '✕'}</span>
            <span class="notification-message">${message}</span>
        </div>
    `;

    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 30px;
        background: ${type === 'success' ? '#D85D7A' : '#E5989B'};
        color: white;
        padding: 1.2rem 2rem;
        border-radius: 50px;
        box-shadow: 0 8px 30px rgba(255, 192, 203, 0.4);
        z-index: 10000;
        animation: slideIn 0.4s ease;
        display: flex;
        align-items: center;
        gap: 1rem;
        font-weight: 600;
    `;

    document.body.appendChild(notification);

    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.4s ease';
        setTimeout(() => notification.remove(), 400);
    }, 3000);
}

// ===== QUICK VIEW MODAL =====
function openQuickView(productId) {
    fetch(`/product-quick-view.php?id=${productId}`)
        .then(response => response.text())
        .then(html => {
            const modal = document.createElement('div');
            modal.className = 'quick-view-modal';
            modal.innerHTML = html;
            document.body.appendChild(modal);

            // Close modal
            modal.querySelector('.close-modal').addEventListener('click', () => {
                modal.remove();
            });

            // Close on outside click
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.remove();
                }
            });
        })
        .catch(error => console.error('Error:', error));
}

// ===== SEARCH FUNCTIONALITY =====
const searchInput = document.querySelector('.search-input');
const searchResults = document.querySelector('.search-results');

if (searchInput) {
    let searchTimeout;

    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        const query = e.target.value.trim();

        if (query.length < 2) {
            if (searchResults) searchResults.style.display = 'none';
            return;
        }

        searchTimeout = setTimeout(() => {
            fetch(`/search.php?q=${encodeURIComponent(query)}&ajax=1`)
                .then(response => response.text())
                .then(html => {
                    if (searchResults) {
                        searchResults.innerHTML = html;
                        searchResults.style.display = 'block';
                    }
                })
                .catch(error => console.error('Error:', error));
        }, 300);
    });

    // Close search results on outside click
    document.addEventListener('click', (e) => {
        if (searchResults && !searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.style.display = 'none';
        }
    });
}

// ===== QUANTITY SELECTOR =====
document.querySelectorAll('.quantity-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const input = btn.parentElement.querySelector('.quantity-input');
        const currentValue = parseInt(input.value) || 1;
        const max = parseInt(input.max) || 999;

        if (btn.classList.contains('quantity-minus')) {
            if (currentValue > 1) {
                input.value = currentValue - 1;
            }
        } else if (btn.classList.contains('quantity-plus')) {
            if (currentValue < max) {
                input.value = currentValue + 1;
            }
        }
    });
});

// ===== NEWSLETTER POPUP =====
window.addEventListener('load', () => {
    setTimeout(() => {
        const hasSeenNewsletter = localStorage.getItem('newsletter_seen');
        if (!hasSeenNewsletter) {
            showNewsletterPopup();
        }
    }, 10000); // Show after 10 seconds
});

function showNewsletterPopup() {
    const popup = document.createElement('div');
    popup.className = 'newsletter-popup';
    popup.innerHTML = `
        <div class="newsletter-content">
            <button class="close-newsletter">✕</button>
            <h2>Join Our Pink Club! 💖</h2>
            <p>Get 10% off your first order + exclusive updates</p>
            <form class="newsletter-form">
                <input type="email" placeholder="Your email" required>
                <button type="submit">Subscribe</button>
            </form>
        </div>
    `;

    document.body.appendChild(popup);

    popup.querySelector('.close-newsletter').addEventListener('click', () => {
        popup.remove();
        localStorage.setItem('newsletter_seen', 'true');
    });

    popup.querySelector('.newsletter-form').addEventListener('submit', (e) => {
        e.preventDefault();
        showNotification('Thank you for subscribing!', 'success');
        popup.remove();
        localStorage.setItem('newsletter_seen', 'true');
    });
}

// ===== COUNTDOWN TIMER =====
function startCountdown(endDate, elementId) {
    const countdownElement = document.getElementById(elementId);
    if (!countdownElement) return;

    const countdownInterval = setInterval(() => {
        const now = new Date().getTime();
        const distance = new Date(endDate).getTime() - now;

        if (distance < 0) {
            clearInterval(countdownInterval);
            countdownElement.innerHTML = 'OFFER ENDED';
            return;
        }

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        countdownElement.innerHTML = `
            <span>${days}d</span> :
            <span>${hours}h</span> :
            <span>${minutes}m</span> :
            <span>${seconds}s</span>
        `;
    }, 1000);
}

// ===== IMAGE GALLERY =====
function initImageGallery() {
    const mainImage = document.querySelector('.main-product-image');
    const thumbnails = document.querySelectorAll('.thumbnail-image');

    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', () => {
            thumbnails.forEach(t => t.classList.remove('active'));
            thumb.classList.add('active');
            mainImage.src = thumb.src;
        });
    });
}

// ===== INITIALIZE ON PAGE LOAD =====
document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
    updateWishlistCount();
    initImageGallery();
});

// ===== LAZY LOADING IMAGES =====
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img.lazy').forEach(img => {
        imageObserver.observe(img);
    });
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
