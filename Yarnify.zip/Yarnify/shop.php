<?php
require_once 'config/db.php';

// Get filter parameters
$category = $_GET['category'] ?? '';
$sort = $_GET['sort'] ?? 'newest';
$search = $_GET['search'] ?? '';

// Build query
$query = "SELECT * FROM products WHERE 1=1";
$params = [];
$types = "";

if ($category && $category !== 'all') {
    $query .= " AND category = ?";
    $params[] = $category;
    $types .= "s";
}

if ($search) {
    $query .= " AND (name LIKE ? OR description LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $types .= "ss";
}

// Sorting
switch ($sort) {
    case 'price_low':
        $query .= " ORDER BY price ASC";
        break;
    case 'price_high':
        $query .= " ORDER BY price DESC";
        break;
    case 'bestseller':
        $query .= " ORDER BY is_bestseller DESC, created_at DESC";
        break;
    default:
        $query .= " ORDER BY created_at DESC";
}

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$products = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - YARNIFY</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        :root {
            --deep-rose: #D85D7A;
            --soft-pink: #FFE4E9;
            --light-pink: #FFF0F5;
        }

        .shop-header {
            background: var(--light-pink);
            padding: 8rem 5% 3rem;
            text-align: center;
            margin-top: 0px;
        }

        .shop-header h1 {
            font-size: 3.5rem;
            margin-bottom: 1rem;
            color: #8B2E4A;
        }

        .filters-container {
            background: white;
            padding: 2rem 5%;
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            border-radius: 30px;
            margin: -2rem 5% 3rem;
            position: relative;
            z-index: 10;
        }

        .filter-group {
            display: flex;
            gap: 1rem;
            align-items: center;
        }

        .filter-select {
            padding: 0.8rem 1.5rem;
            border: 2px solid var(--soft-pink);
            border-radius: 25px;
            background: white;
            color: #333;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.4s ease;
        }

        .filter-select:focus {
            outline: none;
            border-color: var(--deep-rose);
            box-shadow: 0 0 0 2px rgba(216, 93, 122, 0.2);
        }

        .search-box {
            padding: 0.8rem 1.5rem;
            border: 2px solid var(--soft-pink);
            border-radius: 25px;
            background: white;
            color: #333;
            font-family: 'Poppins', sans-serif;
            min-width: 250px;
        }

        .search-box:focus {
            outline: none;
            border-color: var(--deep-rose);
        }

        .products-count {
            color: #666;
            font-size: 0.95rem;
        }

        /* Footer styling - same as index.php */
        .footer {
            margin-top: 80px;
            padding: 3rem 2rem 2rem;
            background: var(--gradient-pink);
            width: 100%;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 40px;
        }

        .footer-section {
            display: flex;
            flex-direction: column;
        }

        .footer-section h3 {
            color: #8B2E4A;
            margin-bottom: 20px;
            font-size: 1.2rem;
        }

        .footer-section p {
            color: #666;
            line-height: 1.5;
            margin-bottom: 1rem;
        }

        .footer-section a {
            color: #A0526D;
            text-decoration: none;
            margin-bottom: 10px;
            transition: color 0.3s ease;
        }

        .footer-section a:hover {
            color: #D85D7A;
        }

        .social-links {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }

        .social-icon {
            color: #8B2E4A;
            transition: color 0.3s;
        }

        .social-icon:hover {
            color: #D85D7A;
        }

        .footer-bottom {
            margin-top: 60px;
            padding: 30px 0;
            text-align: center;
            border-top: 1px solid rgba(176, 48, 82, 0.1);
            color: #8B2E4A;
        }

        /* Responsive Shop Styles */
        @media (max-width: 1024px) {
            .shop-header {
                padding: 6rem 5% 2rem;
            }

            .shop-header h1 {
                font-size: 2.8rem;
            }

            .filters-container {
                padding: 1.5rem 5%;
                margin: -1.5rem 5% 2rem;
                flex-direction: column;
                align-items: stretch;
                gap: 1.5rem;
            }

            .filter-group {
                width: 100%;
                justify-content: space-between;
            }

            .search-box {
                min-width: 200px;
                width: 100%;
            }

            .product-grid {
                grid-template-columns: repeat(3, 1fr);
                padding: 0 20px;
            }

            .footer-content {
                grid-template-columns: repeat(2, 1fr);
                gap: 30px;
            }
        }

        @media (max-width: 768px) {
            .shop-header {
                padding: 5rem 5% 2rem;
                margin-top: 0;
            }

            .shop-header h1 {
                font-size: 2.2rem;
            }

            .shop-header p {
                font-size: 1rem;
            }

            .filters-container {
                padding: 1.2rem 4%;
                margin: -1.2rem 4% 2rem;
                border-radius: 20px;
                gap: 1.2rem;
            }

            .filter-group {
                flex-wrap: wrap;
                gap: 0.8rem;
            }

            .filter-select,
            .search-box {
                padding: 0.7rem 1.2rem;
                font-size: 0.9rem;
            }

            .filter-select {
                flex: 1;
                min-width: 150px;
            }

            .products-count {
                text-align: center;
                width: 100%;
                margin-top: 0.5rem;
            }

            .product-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
                padding: 0 15px;
            }

            .footer-content {
                grid-template-columns: 1fr;
                gap: 40px;
            }

            /* Responsive navbar for shop page */
            .navbar {
                padding: 15px 20px;
                position: fixed;
                top: 0;
                width: 100%;
                background: white;
                z-index: 1000;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }

            .shop-header {
                padding-top: 7rem; /* Account for fixed navbar */
            }

            .nav-left, .nav-right {
                position: fixed;
                width: 100%;
                background: white;
                padding: 1rem;
                box-shadow: 0 10px 20px rgba(0,0,0,0.1);
                z-index: 999;
                display: none; /* Hidden by default on mobile */
            }

            .nav-left.active, .nav-right.active {
                display: flex;
            }

            .nav-left {
                top: 60px;
                left: 0;
                flex-direction: column;
                gap: 15px;
            }

            .nav-right {
                bottom: 0;
                left: 0;
                justify-content: space-around;
                border-top: 1px solid #eee;
                padding: 15px;
            }

            .menu-toggle {
                display: flex;
                flex-direction: column;
                gap: 4px;
                cursor: pointer;
                z-index: 1001;
            }

            .menu-toggle span {
                width: 25px;
                height: 3px;
                background-color: #D85D7A;
                transition: 0.3s;
            }

            .menu-toggle.active span:nth-child(1) {
                transform: rotate(45deg) translate(6px, 6px);
            }

            .menu-toggle.active span:nth-child(2) {
                opacity: 0;
            }

            .menu-toggle.active span:nth-child(3) {
                transform: rotate(-45deg) translate(6px, -6px);
            }
        }

        @media (max-width: 480px) {
            .shop-header {
                padding: 6rem 4% 1.5rem;
            }

            .shop-header h1 {
                font-size: 1.8rem;
            }

            .filters-container {
                padding: 1rem 4%;
                margin: -1rem 4% 1.5rem;
                gap: 1rem;
            }

            .filter-group {
                flex-direction: column;
                align-items: stretch;
                gap: 0.8rem;
            }

            .filter-group label {
                text-align: center;
            }

            .filter-select,
            .search-box {
                width: 100%;
                text-align: center;
            }

            .product-grid {
                grid-template-columns: 1fr;
                gap: 15px;
                padding: 0 10px;
            }

            .product-card {
                max-width: 100%;
            }

            .section {
                padding: 1rem 0;
            }

            .whatsapp-float {
                width: 50px;
                height: 50px;
                bottom: 20px;
                right: 15px;
            }
        }

        /* Mobile menu toggle animation */
        @media (max-width: 768px) {
            .nav-left, .nav-right {
                transition: transform 0.3s ease;
            }

            .nav-left {
                transform: translateX(-100%);
            }

            .nav-left.active {
                transform: translateX(0);
            }

            .nav-right {
                transform: translateX(100%);
            }

            .nav-right.active {
                transform: translateX(0);
            }
        }

        /* Ensure product images are responsive */
        .product-image {
            width: 100%;
            height: auto;
            aspect-ratio: 1/1;
            object-fit: cover;
        }

        /* Responsive product card */
        .product-card {
            transition: transform 0.3s ease;
        }

        .product-card:hover {
            transform: translateY(-5px);
        }

        /* Fix for sticky header spacing */
        body {
            padding-top: 0;
        }

        /* Add smooth scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Product grid styles */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 2rem;
            padding: 2rem 0;
            max-width: 1200px;
            margin: 0 auto;
        }

        .product-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        .product-image-container {
            height: 200px;
            overflow: hidden;
        }

        .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }

        .product-card:hover .product-image {
            transform: scale(1.05);
        }

        .product-info {
            padding: 1.2rem;
        }

        .product-name {
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
            color: #333;
        }

        .product-price {
            font-weight: 600;
            color: #D85D7A;
            margin-bottom: 1rem;
        }

        .product-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .add-to-cart-btn {
            background: #D85D7A;
            color: white;
            border: none;
            padding: 0.6rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: background 0.3s;
        }

        .add-to-cart-btn:hover {
            background: #B03052;
        }

        .wishlist-btn {
            background: transparent;
            border: none;
            padding: 0.5rem;
            cursor: pointer;
            color: #D85D7A;
        }

        .section {
            padding: 4rem 2rem;
            background: white;
        }

        .section-title {
            text-align: center;
            margin-bottom: 2rem;
            font-size: 2rem;
            color: #8B2E4A;
        }

        .tabs-container {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }

        .tab-btn {
            padding: 0.8rem 1.5rem;
            margin: 0 0.5rem 1rem;
            background: #f8f8f8;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .tab-btn.active {
            background: #D85D7A;
            color: white;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .reveal {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.6s ease, transform 0.6s ease;
        }

        .reveal.active {
            opacity: 1;
            transform: translateY(0);
        }

        html, body {
            height: 100%;
        }

        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        main {
            flex: 1;
        }

    /* ===== UNIVERSAL FOOTER STYLE ===== */
.footer {
    background: var(--gradient-pink);
    padding: 3rem 5% 2rem;
    margin-top: 5rem;
    width: 100%;
    border-top: 1px solid rgba(216, 93, 122, 0.1);
}

.footer-content {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
}

.footer-section h3 {
    color: #D85D7A;
    margin-bottom: 1.5rem;
    font-size: 1.3rem;
    font-family: 'Playfair Display', serif;
    font-weight: 600;
    position: relative;
    padding-bottom: 0.5rem;
}

.footer-section h3::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 50px;
    height: 2px;
    background: #D85D7A;
}

.footer-section p {
    color: #666666;
    line-height: 1.6;
    margin-bottom: 1rem;
    font-family: 'Poppins', sans-serif;
    font-size: 0.95rem;
}

.footer-section a {
    color: #A0526D;
    text-decoration: none;
    margin-bottom: 0.8rem;
    display: block;
    font-family: 'Poppins', sans-serif;
    font-size: 0.95rem;
    transition: all 0.3s ease;
}

.footer-section a:hover {
    color: #D85D7A;
    padding-left: 5px;
}

.social-links {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
    justify-content: flex-start;
}

.social-icon {
    width: 40px;
    height: 40px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #D85D7A;
    transition: all 0.3s ease;
    box-shadow: 0 2px 10px rgba(216, 93, 122, 0.1);
}

.social-icon:hover {
    background: #D85D7A;
    color: white;
    transform: translateY(-3px);
}

.newsletter-form {
    display: flex;
    gap: 0.5rem;
    margin-top: 1rem;
}

.newsletter-input {
    flex: 1;
    padding: 0.8rem 1rem;
    border: 2px solid #FFE4E9;
    border-radius: 25px;
    font-family: 'Poppins', sans-serif;
    font-size: 0.95rem;
    outline: none;
    transition: all 0.3s ease;
}

.newsletter-input:focus {
    border-color: #D85D7A;
    box-shadow: 0 0 0 3px rgba(216, 93, 122, 0.2);
}

.join-btn {
    padding: 0.8rem 1.5rem;
    background: #D85D7A;
    color: white;
    border: none;
    border-radius: 25px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.join-btn:hover {
    background: #B03052;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(216, 93, 122, 0.3);
}

.footer-bottom {
    text-align: center;
    padding-top: 2rem;
    margin-top: 2rem;
    border-top: 1px solid rgba(216, 93, 122, 0.1);
    color: #8B2E4A;
    font-family: 'Poppins', sans-serif;
    font-size: 0.9rem;
}

/* Responsive footer */
@media (max-width: 768px) {
    .footer-content {
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
    }

    .footer-section h3 {
        font-size: 1.2rem;
    }

    .social-links {
        justify-content: center;
    }

    .newsletter-form {
        flex-direction: column;
    }

    .footer {
        padding: 2rem 5% 1.5rem;
    }
}

@media (max-width: 480px) {
    .footer-content {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }

    .footer-section {
        text-align: center;
    }

    .social-links {
        justify-content: center;
    }
}

    </style>
    <link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>

        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>

        <div class="nav-right">
            <a href="<?php echo isset($_SESSION['user_id']) ? 'wishlist.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <span class="wishlist-count" style="display: none;">0</span>
            </a>
            <a href="<?php echo isset($_SESSION['user_id']) ? 'cart.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
                <span class="cart-count" style="display: none;">0</span>
            </a>
            <a href="<?php echo isset($_SESSION['user_id']) ? 'profile.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>

        <div class="menu-toggle">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

<main>
    <!-- Shop Header -->
    <div class="shop-header">
        <h1>Shop All Products</h1>
        <p style="font-size: 1.2rem; color: #A0526D;">Discover our handmade treasures</p>
    </div>

    <!-- Filters -->
    <div class="filters-container">
        <div class="filter-group">
            <label style="font-weight: 600; color: #8B2E4A;">Category:</label>
            <select class="filter-select" onchange="window.location.href='?category=' + this.value + '&sort=<?php echo $sort; ?>'">
                <option value="all" <?php echo $category === '' || $category === 'all' ? 'selected' : ''; ?>>All Products</option>
                <option value="bags" <?php echo $category === 'bags' ? 'selected' : ''; ?>>Bags</option>
                <option value="tops" <?php echo $category === 'tops' ? 'selected' : ''; ?>>Tops</option>
                <option value="accessories" <?php echo $category === 'accessories' ? 'selected' : ''; ?>>Accessories</option>
                <option value="plushies" <?php echo $category === 'plushies' ? 'selected' : ''; ?>>Plushies</option>
            </select>
        </div>

        <div class="filter-group">
            <label style="font-weight: 600; color: #8B2E4A;">Sort by:</label>
            <select class="filter-select" onchange="window.location.href='?category=<?php echo $category; ?>&sort=' + this.value">
                <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest First</option>
                <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                <option value="bestseller" <?php echo $sort === 'bestseller' ? 'selected' : ''; ?>>Best Sellers</option>
            </select>
        </div>

        <form method="GET" class="filter-group" style="flex: 1; justify-content: flex-end;">
            <input type="hidden" name="category" value="<?php echo $category; ?>">
            <input type="hidden" name="sort" value="<?php echo $sort; ?>">
            <input type="text" name="search" class="search-box" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>">
        </form>

        <span class="products-count"><?php echo $products->num_rows; ?> products found</span>
    </div>

    <!-- Products Grid -->
    <section class="section" style="padding-top: 2rem;">
        <div class="product-grid">
            <?php if ($products->num_rows > 0): ?>
                <?php while ($product = $products->fetch_assoc()): ?>
                <div class="product-card reveal">
                    <?php if ($product['is_trending']): ?>
                    <span class="product-badge">Trending</span>
                    <?php elseif ($product['is_bestseller']): ?>
                    <span class="product-badge">Best Seller</span>
                    <?php endif; ?>

                    <div class="product-image-container">
                        <img src="assets/images/products/<?php echo $product['image']; ?>"
                             alt="<?php echo htmlspecialchars($product['name']); ?>"
                             class="product-image">
                    </div>

                    <div class="product-info">
                        <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p class="product-price">₹<?php echo number_format($product['price'], 2); ?></p>

                        <?php if ($product['stock'] > 0): ?>
                        <div class="product-actions">
                            <button class="add-to-cart-btn" onclick="addToCart(<?php echo $product['id']; ?>)">Add to Cart</button>
                            <button class="wishlist-btn" onclick="addToWishlist(<?php echo $product['id']; ?>)">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                                </svg>
                            </button>
                        </div>
                        <?php else: ?>
                        <p style="color: #E5989B; font-weight: 600; text-align: center; padding: 1rem;">Out of Stock</p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 4rem;">
                    <h2 style="color: #A0526D;">No products found</h2>
                    <p style="margin-top: 1rem;">Try adjusting your filters or search term</p>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

     <footer class="footer">
    <div class="footer-content">
        <div class="footer-section">
            <h3>About Us</h3>
            <p>We create handmade crochet pieces with love and care. Each item is unique and crafted to bring joy to your life.</p>
            <p>Yarnify is a handmade crochet brand offering affordable and customizable accessories crafted with love.</p>
            <div class="social-links">
                <a href="#" class="social-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                    </svg>
                </a>
                <a href="#" class="social-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-9-9 9 9 0 0 1 9-9c2.5 0 4.8.9 6.5 2.4"/>
                        <path d="M16 8h-2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v-4h-1"/>
                    </svg>
                </a>
                <a href="#" class="social-icon">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                        <path d="M22 6l-10 7L2 6"/>
                    </svg>
                </a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Quick Links</h3>
            <a href="shop.php">Shop</a>
            <a href="collections.php">Collections</a>
            <a href="about.php">About</a>
            <a href="reviews.php">Reviews</a>
        </div>
        <div class="footer-section">
            <h3>Customer Care</h3>
            <a href="#">Shipping Info</a>
            <a href="#">Returns</a>
            <a href="#">FAQ</a>
            <a href="#">Contact Us</a>
        </div>
        <div class="footer-section">
            <h3>Newsletter</h3>
            <p>Subscribe for exclusive offers and updates!</p>
            <form class="newsletter-form">
                <input type="email" class="newsletter-input" placeholder="Your email">
                <button type="submit" class="join-btn">Join</button>
            </form>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2026 YARNIFY. Made with 💖 | All Rights Reserved</p>
    </div>
</footer>

    <!-- Floating WhatsApp -->
    <a href="https://wa.me/8291387452" class="whatsapp-float" target="_blank">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="white">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
    </a>

    <script src="assets/js/main.js"></script>
    <script>
        // Mobile menu toggle for shop page
        document.addEventListener('DOMContentLoaded', function() {
            const menuToggle = document.querySelector('.menu-toggle');
            const navLeft = document.querySelector('.nav-left');
            const navRight = document.querySelector('.nav-right');

            if (menuToggle) {
                menuToggle.addEventListener('click', function() {
                    this.classList.toggle('active');
                    navLeft.classList.toggle('active');
                    navRight.classList.toggle('active');

                    // Prevent body scrolling when menu is open
                    if (this.classList.contains('active')) {
                        document.body.style.overflow = 'hidden';
                    } else {
                        document.body.style.overflow = '';
                    }
                });

                // Close menu when clicking on a nav link
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.addEventListener('click', function() {
                        menuToggle.classList.remove('active');
                        navLeft.classList.remove('active');
                        navRight.classList.remove('active');
                        document.body.style.overflow = '';
                    });
                });
            }

            // Auto-submit search on mobile when pressing enter
            const searchBox = document.querySelector('.search-box');
            if (searchBox) {
                searchBox.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        this.closest('form').submit();
                    }
                });
            }

            // Adjust shop header padding based on navbar height
            function adjustShopHeader() {
                const navbar = document.querySelector('.navbar');
                const shopHeader = document.querySelector('.shop-header');

                if (navbar && shopHeader && window.innerWidth <= 768) {
                    const navbarHeight = navbar.offsetHeight;
                    shopHeader.style.paddingTop = (navbarHeight + 20) + 'px';
                }
            }

            // Adjust on load and resize
            window.addEventListener('load', adjustShopHeader);
            window.addEventListener('resize', adjustShopHeader);
        });
    </script>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>
