<?php
require_once 'config/db.php';

// Fetch all approved reviews
$reviews_query = "SELECT r.*, u.name as user_name, p.name as product_name, p.image as product_image
                  FROM reviews r
                  JOIN users u ON r.user_id = u.id
                  JOIN products p ON r.product_id = p.id
                  WHERE r.status = 'approved'
                  ORDER BY r.created_at DESC
                  LIMIT 50";
$reviews = $conn->query($reviews_query);

// Calculate overall stats
$stats_query = "SELECT AVG(rating) as avg_rating, COUNT(*) as total_reviews FROM reviews WHERE status = 'approved'";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

// Set default values if no reviews exist
if ($stats['avg_rating'] === null) {
    $stats['avg_rating'] = 0;
}
if ($stats['total_reviews'] === null) {
    $stats['total_reviews'] = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Reviews - YARNIFY</title>
    <link rel="stylesheet" href="style.css">
    <style>
        :root {
            --deep-rose: #D85D7A;
            --gradient-pink: linear-gradient(135deg, #FFE4E9 0%, #FFF0F5 100%);
            --soft-pink: #FFE4E9;
            --light-pink: #FFF0F5;
            --text-dark: #333;
            --text-light: #666;
            --shadow-soft: 0 4px 12px rgba(0, 0, 0, 0.05);
            --shadow-medium: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        .reviews-container {
            max-width: 1200px;
            margin: 120px auto 3rem;
            padding: 0 5%;
        }

        .reviews-header {
            text-align: center;
            background: var(--gradient-pink);
            padding: 3rem;
            border-radius: 30px;
            margin-bottom: 3rem;
        }

        .reviews-header h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: #8B2E4A;
        }

        .overall-rating {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
            font-size: 1.5rem;
            margin-top: 1rem;
        }

        .stars-large {
            display: flex;
            gap: 0.3rem;
        }

        .star-large {
            color: #FFD700;
            font-size: 2rem;
        }

        .star-large.empty {
            color: #E0E0E0;
        }

        .review-card {
            background: white;
            padding: 2.5rem;
            border-radius: 25px;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-soft);
            transition: all 0.4s ease;
        }

        .review-card:hover {
            box-shadow: var(--shadow-medium);
            transform: translateY(-3px);
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 1.5rem;
        }

        .reviewer-info {
            display: flex;
            gap: 1rem;
        }

        .reviewer-avatar {
            width: 60px;
            height: 60px;
            background: var(--gradient-pink);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--deep-rose);
        }

        .reviewer-details h3 {
            margin-bottom: 0.3rem;
            color: var(--text-dark);
        }

        .stars {
            display: flex;
            gap: 0.2rem;
            margin: 0.3rem 0;
        }

        .star {
            font-size: 1.2rem;
        }

        .review-product {
            display: flex;
            align-items: center;
            gap: 1rem;
            background: var(--light-pink);
            padding: 1rem;
            border-radius: 15px;
            margin-top: 1rem;
        }

        .review-product-image {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            overflow: hidden;
        }

        .review-product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .empty {
            color: var(--soft-pink) !important;
        }
    </style>
    <link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>

        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>

        <div class="nav-right">
            <a href="<?php echo isLoggedIn() ? 'wishlist.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
            </a>
            <a href="<?php echo isLoggedIn() ? 'cart.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
            </a>
            <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
    </nav>

    <div class="reviews-container">
        <div class="reviews-header reveal" style="font-color:var(--deep-rose);">
            <h1>Customer Reviews</h1>
            <p style="font-size: 1.2rem; color: var(--text-light);">See what our customers are saying</p>
            <div class="overall-rating">
                <div class="stars-large">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                    <span class="star-large <?php echo $i <= round($stats['avg_rating']) ? '' : 'empty'; ?>">★</span>
                    <?php endfor; ?>
                </div>
                <span><?php echo number_format($stats['avg_rating'], 1); ?> out of 5</span>
                <span style="color: var(--text-light);">(<?php echo $stats['total_reviews']; ?> reviews)</span>
            </div>
        </div>

        <?php if ($reviews->num_rows > 0): ?>
            <?php while ($review = $reviews->fetch_assoc()): ?>
            <div class="review-card reveal">
                <div class="review-header">
                    <div class="reviewer-info">
                        <div class="reviewer-avatar">
                            <?php echo strtoupper(substr($review['user_name'], 0, 1)); ?>
                        </div>
                        <div class="reviewer-details">
                            <h3><?php echo htmlspecialchars($review['user_name']); ?></h3>
                            <div class="stars">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <span class="star" style="color: <?php echo $i <= $review['rating'] ? '#FFD700' : 'var(--soft-pink)'; ?>">★</span>
                                <?php endfor; ?>
                            </div>
                            <p style="color: var(--text-light); font-size: 0.9rem; margin-top: 0.3rem;">
                                <?php echo date('F d, Y', strtotime($review['created_at'])); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <p style="line-height: 1.7; color: var(--text-dark); font-size: 1.05rem;">
                    <?php echo nl2br(htmlspecialchars($review['comment'])); ?>
                </p>

                <div class="review-product">
                    <div class="review-product-image">
                        <img src="assets/images/products/<?php echo $review['product_image']; ?>" alt="">
                    </div>
                    <div>
                        <div style="font-weight: 600; color: var(--text-dark);"><?php echo htmlspecialchars($review['product_name']); ?></div>
                        <a href="product.php?id=<?php echo $review['product_id']; ?>" style="color: var(--deep-rose); font-size: 0.9rem;">View Product →</a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="text-align: center; padding: 4rem; background: white; border-radius: 30px;">
                <h2 style="color: var(--text-light);">No reviews yet</h2>
                <p style="margin: 1rem 0;">Be the first to share your experience!</p>
            </div>
        <?php endif; ?>
    </div>

  <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care. Each item is unique and crafted to bring joy to your life.</p>
                <p>Yarnify is a handmade crochet brand offering affordable and customizable accessories crafted with love.</p>
                <div class="social-links">
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-9-9 9 9 0 0 1 9-9c2.5 0 4.8.9 6.5 2.4"/>
                            <path d="M16 8h-2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v-4h-1"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <path d="M22 6l-10 7L2 6"/>
                        </svg>
                    </a>
                </div>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="shop.php">Shop</a>
                <a href="collections.php">Collections</a>
                <a href="about.php">About</a>
                <a href="reviews.php">Reviews</a>
            </div>
            <div class="footer-section">
                <h3>Customer Care</h3>
                <a href="#">Shipping Info</a>
                <a href="#">Returns</a>
                <a href="#">FAQ</a>
                <a href="#">Contact Us</a>
            </div>
            <div class="footer-section">
                <h3>Newsletter</h3>
                <p>Subscribe for exclusive offers and updates!</p>
                <form style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                    <input type="email" placeholder="Your email" style="flex: 1; padding: 0.8rem; border-radius: 25px; border: none;">
                    <button type="submit" class="btn-primary" style="padding: 0.8rem 1.5rem;">Join</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 YARNIFY. Made with 💖 | All Rights Reserved</p>
        </div>
    </footer>

    <script>
        // Animation for reveal effect
        document.addEventListener('DOMContentLoaded', function() {
            const revealElements = document.querySelectorAll('.reveal');

            const revealOnScroll = () => {
                revealElements.forEach(element => {
                    const elementTop = element.getBoundingClientRect().top;
                    const windowHeight = window.innerHeight;

                    if (elementTop < windowHeight - 100) {
                        element.classList.add('active');
                    }
                });
            };

            // Initial check
            revealOnScroll();

            // Check on scroll
            window.addEventListener('scroll', revealOnScroll);
        });
    </script>
</body>
</html>
