<?php
require_once 'config/db.php';

$query = $_GET['q'] ?? '';
$results = [];

if ($query) {
    $search_term = "%$query%";
    $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? OR description LIKE ? LIMIT 20");
    $stmt->bind_param("ss", $search_term, $search_term);
    $stmt->execute();
    $results = $stmt->get_result();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results - Crochet Luxury</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>
        
        <div class="nav-center">
            <a href="index.php" class="brand-name">Crochet Luxury</a>
        </div>
        
        <div class="nav-right">
            <a href="wishlist.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
            </a>
            <a href="cart.php">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
            </a>
            <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
    </nav>

    <div class="section" style="margin-top: 120px;">
        <h2 class="section-title">Search Results for "<?php echo htmlspecialchars($query); ?>"</h2>
        <p style="text-align: center; color: var(--text-light); margin-bottom: 3rem;">
            Found <?php echo $results->num_rows; ?> products
        </p>
        
        <?php if ($results->num_rows > 0): ?>
        <div class="product-grid">
            <?php while ($product = $results->fetch_assoc()): ?>
            <div class="product-card">
                <div class="product-image-container">
                    <img src="assets/images/products/<?php echo $product['image']; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
                </div>
                <div class="product-info">
                    <h3 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p class="product-price">$<?php echo number_format($product['price'], 2); ?></p>
                    <div class="product-actions">
                        <a href="product.php?id=<?php echo $product['id']; ?>">
                            <button class="add-to-cart-btn">View Details</button>
                        </a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <?php else: ?>
        <div style="text-align: center; padding: 4rem;">
            <h3>No products found</h3>
            <p style="color: var(--text-light);">Try searching with different keywords</p>
        </div>
        <?php endif; ?>
    </div>

    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care.</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2025 Crochet Luxury. Made with 💖</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>
