# 🌸 Crochet Luxury - Premium E-Commerce Website

A fully functional, production-ready luxury e-commerce website for a handmade crochet brand, featuring a soft pink aesthetic and premium user experience.

## ✨ Features

### 🎨 Design
- **Luxury Pink Color Scheme**: Soft pink palette with glassmorphism effects
- **Responsive Design**: Mobile-first approach, works on all devices
- **Smooth Animations**: Floating products, scroll reveals, hover effects
- **Wave Dividers**: Elegant section separators inspired by premium Shopify themes
- **3D Product Displays**: Floating hero products with parallax effects

### 🛍️ Customer Features
- **Product Browsing**: Filter by category, price, trending, and bestsellers
- **Shopping Cart**: Real-time cart updates with quantity controls
- **Wishlist**: Save favorite products (requires login)
- **User Authentication**: Secure login/register system
- **User Profile**: Order history, wishlist management, account settings
- **Search**: Live search with instant results
- **Reviews**: Rate and review products
- **Checkout**: Complete order placement system
- **Order Tracking**: Track order status from pending to delivered

### 👑 Admin Features
- **Dashboard**: Sales analytics, order statistics, customer metrics
- **Product Management**: Add, edit, delete products with image uploads
- **Order Management**: View, update order status, track deliveries
- **Customer Management**: View customer data, block/unblock users
- **Review Moderation**: Approve/reject customer reviews
- **Inventory Control**: Stock management system

### 🔐 Security
- **Password Hashing**: bcrypt encryption
- **SQL Injection Protection**: Prepared statements
- **CSRF Protection**: Token-based validation
- **Form Validation**: Client and server-side validation
- **Session Security**: Secure session management
- **Admin Role Protection**: Route access control

## 📁 File Structure

```
crochet-luxury-shop/
├── assets/
│   ├── css/
│   │   └── style.css              # Main stylesheet with luxury pink design
│   ├── js/
│   │   └── main.js                # JavaScript for animations & interactions
│   └── images/
│       └── products/              # Product images
├── config/
│   └── db.php                     # Database configuration & security functions
├── admin/
│   ├── dashboard.php              # Admin dashboard with statistics
│   ├── products.php               # Product management
│   ├── add-product.php            # Add new products
│   ├── orders.php                 # Order management
│   ├── customers.php              # Customer management
│   └── reviews.php                # Review moderation
├── index.php                      # Homepage with hero section
├── shop.php                       # Product listing with filters
├── product.php                    # Product detail page
├── cart.php                       # Shopping cart
├── checkout.php                   # Checkout process
├── wishlist.php                   # Wishlist page
├── profile.php                    # User profile & order history
├── login.php                      # Login page
├── register.php                   # Registration page
├── logout.php                     # Logout handler
├── cart-handler.php               # Cart AJAX operations
├── wishlist-handler.php           # Wishlist AJAX operations
├── search.php                     # Search functionality
├── collections.php                # Product collections
├── about.php                      # About page
├── reviews.php                    # Reviews page
├── order-success.php              # Order confirmation
└── database.sql                   # Database schema
```

## 🚀 Installation

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- Composer (optional)

### Step 1: Database Setup
1. Create a MySQL database named `crochet_luxury`
2. Import the database schema:
```bash
mysql -u your_username -p crochet_luxury < database.sql
```

### Step 2: Configuration
1. Update database credentials in `config/db.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'crochet_luxury');
```

### Step 3: File Permissions
```bash
chmod 755 assets/images/products
```

### Step 4: Web Server Configuration

#### Apache (.htaccess)
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
```

#### Nginx
```nginx
location / {
    try_files $uri $uri/ /index.php?$query_string;
}
```

### Step 5: Default Admin Account
- Email: `admin@crochetluxury.com`
- Password: `admin123`
- **⚠️ CHANGE THIS IMMEDIATELY AFTER FIRST LOGIN**

## 🎨 Design System

### Color Palette
```css
--light-pink: #FFF5F7;        /* Backgrounds */
--soft-pink: #FFE4E9;         /* Cards, accents */
--baby-pink: #FFD6E0;         /* Gradients */
--primary-pink: #FFC0CB;      /* Primary elements */
--rose-pink: #FFB3C1;         /* Highlights */
--dusty-pink: #E5989B;        /* Muted elements */
--deep-rose: #D85D7A;         /* CTAs, emphasis */
```

### Typography
- **Headings**: Playfair Display (serif)
- **Body**: Poppins (sans-serif)

### Animations
- Floating product: 6s ease-in-out loop
- Scroll reveal: 0.8s ease
- Hover effects: 0.4s ease
- Button ripple effects

## 📊 Database Schema

### Tables
1. **users** - Customer and admin accounts
2. **products** - Product catalog
3. **orders** - Customer orders
4. **order_items** - Order line items
5. **wishlist** - Saved products
6. **reviews** - Product reviews
7. **coupons** - Discount codes

## 🔧 Customization

### Adding Products
1. Login to admin panel
2. Navigate to "Add Product"
3. Fill in product details
4. Upload product image
5. Set category, price, stock
6. Mark as trending/bestseller if desired

### Changing Colors
Edit CSS variables in `assets/css/style.css`:
```css
:root {
    --deep-rose: #YOUR_COLOR;
    --primary-pink: #YOUR_COLOR;
}
```

### Adding Payment Gateway
Integrate in `checkout.php`:
- Stripe
- PayPal
- Square
- Razorpay

## 📱 Mobile Optimization
- Hamburger menu for navigation
- Touch-friendly buttons
- Responsive product grid
- Optimized images
- Smooth scrolling

## 🎯 SEO Features
- Semantic HTML5
- Meta tags ready
- Clean URLs
- Alt text for images
- Structured data ready

## 🌟 Best Practices
- ✅ Prepared statements (SQL injection protection)
- ✅ Password hashing (bcrypt)
- ✅ CSRF tokens
- ✅ Input sanitization
- ✅ Session security
- ✅ Error handling
- ✅ Responsive design
- ✅ Performance optimized

## 🐛 Common Issues

### Issue: Images not displaying
**Solution**: Check file permissions on `assets/images/products/`

### Issue: Database connection error
**Solution**: Verify credentials in `config/db.php`

### Issue: Session not working
**Solution**: Ensure session.save_path is writable

### Issue: Admin can't login
**Solution**: Check that user role is set to 'admin' in database

## 📈 Performance Tips
1. Enable gzip compression
2. Use CDN for static assets
3. Optimize images (WebP format)
4. Enable browser caching
5. Minify CSS/JS for production

## 🔄 Future Enhancements
- [ ] Email notifications
- [ ] SMS order updates
- [ ] Social media login
- [ ] Product recommendations
- [ ] Live chat support
- [ ] Multi-currency support
- [ ] Advanced analytics
- [ ] Newsletter integration
- [ ] Inventory alerts
- [ ] Bulk product import

## 📝 License
This project is proprietary software for Crochet Luxury brand.

## 🤝 Support
For issues or questions, contact the development team.

## 🎉 Credits
- Design inspired by luxury Shopify themes
- Icons: Heroicons
- Fonts: Google Fonts (Playfair Display, Poppins)

---

**Made with 💖 for Crochet Luxury**
