<?php
require_once 'config/db.php';

$categories = [
    'bags' => ['icon' => '👜', 'title' => 'Bags', 'description' => 'Handcrafted totes, shoulder bags, and more'],
    'tops' => ['icon' => '👚', 'title' => 'Tops', 'description' => 'Beautiful crochet tops for every occasion'],
    'accessories' => ['icon' => '✨', 'title' => 'Accessories', 'description' => 'Hair clips, scrunchies, and accessories'],
    'plushies' => ['icon' => '🧸', 'title' => 'Plushies', 'description' => 'Cute and cuddly crochet plushies']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collections - YARNIFY</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .collections-container {
            max-width: 1400px;
            margin: 120px auto 3rem;
            padding: 0 5%;
        }
        
        .collections-header {
            text-align: center;
            margin-bottom: 4rem;
        }
        
        .collections-header h1 {
            font-size: 3.5rem;
            margin-bottom: 1rem;
        }
        
        .collections-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2.5rem;
        }
        
        .collection-card {
            background: white;
            padding: 3rem 2rem;
            border-radius: 30px;
            text-align: center;
            box-shadow: var(--shadow-soft);
            transition: all 0.4s ease;
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .collection-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--gradient-pink);
            opacity: 0;
            transition: opacity 0.4s ease;
        }
        
        .collection-card:hover::before {
            opacity: 0.1;
        }
        
        .collection-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-strong);
        }
        
        .collection-icon {
            font-size: 5rem;
            margin-bottom: 1.5rem;
            position: relative;
            z-index: 1;
        }
        
        .collection-title {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--deep-rose);
            position: relative;
            z-index: 1;
        }
        
        .collection-description {
            color: var(--text-light);
            margin-bottom: 1.5rem;
            position: relative;
            z-index: 1;
        }
        
        .collection-btn {
            padding: 0.8rem 2rem;
            background: var(--deep-rose);
            color: white;
            border-radius: 25px;
            font-weight: 600;
            position: relative;
            z-index: 1;
        }
        
        .collection-btn:hover {
            box-shadow: var(--glow-pink);
        }
    </style>
<link rel="icon" href="assets/images/Yarnify_logo-fotor-20260207203218.png" type="image/png">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-left">
            <a href="shop.php" class="nav-link">Explore</a>
            <a href="collections.php" class="nav-link">Collections</a>
            <a href="about.php" class="nav-link">About</a>
            <a href="reviews.php" class="nav-link">Reviews</a>
        </div>
        
        <div class="nav-center">
            <a href="index.php" class="brand-name">YARNIFY</a>
        </div>
        
        <div class="nav-right">
            <a href="<?php echo isset($_SESSION['user_id']) ? 'wishlist.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                </svg>
                <span class="wishlist-count" style="display: none;">0</span>
            </a>
            <a href="<?php echo isset($_SESSION['user_id']) ? 'cart.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <circle cx="9" cy="21" r="1"/>
                    <circle cx="20" cy="21" r="1"/>
                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                </svg>
                <span class="cart-count" style="display: none;">0</span>
            </a>
            <a href="<?php echo isLoggedIn() ? 'profile.php' : 'login.php'; ?>">
                <svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="#D85D7A" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </a>
        </div>
    </nav>

    <div class="collections-container">
        <div class="collections-header reveal">
            <h1>Our Collections</h1>
            <p style="color: var(--text-light); font-size: 1.2rem;">
                Explore our handmade categories
            </p>
        </div>

        <div class="collections-grid">
            <?php foreach ($categories as $slug => $category): ?>
            <div class="collection-card reveal" onclick="window.location.href='/shop.php?category=<?php echo $slug; ?>'">
                <div class="collection-icon"><?php echo $category['icon']; ?></div>
                <h2 class="collection-title"><?php echo $category['title']; ?></h2>
                <p class="collection-description"><?php echo $category['description']; ?></p>
                <button class="collection-btn">Browse Collection</button>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

     <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Us</h3>
                <p>We create handmade crochet pieces with love and care. Each item is unique and crafted to bring joy to your life.</p>
                <p>Yarnify is a handmade crochet brand offering affordable and customizable accessories crafted with love.</p>
                <div class="social-links">
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 12a9 9 0 0 1-9 9 9 9 0 0 1-9-9 9 9 0 0 1 9-9c2.5 0 4.8.9 6.5 2.4"/>
                            <path d="M16 8h-2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h2v-4h-1"/>
                        </svg>
                    </a>
                    <a href="#" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                            <path d="M22 6l-10 7L2 6"/>
                        </svg>
                    </a>
                </div>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="shop.php">Shop</a>
                <a href="collections.php">Collections</a>
                <a href="about.php">About</a>
                <a href="reviews.php">Reviews</a>
            </div>
            <div class="footer-section">
                <h3>Customer Care</h3>
                <a href="#">Shipping Info</a>
                <a href="#">Returns</a>
                <a href="#">FAQ</a>
                <a href="#">Contact Us</a>
            </div>
            <div class="footer-section">
                <h3>Newsletter</h3>
                <p>Subscribe for exclusive offers and updates!</p>
                <form style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                    <input type="email" placeholder="Your email" style="flex: 1; padding: 0.8rem; border-radius: 25px; border: none;">
                    <button type="submit" class="btn-primary" style="padding: 0.8rem 1.5rem;">Join</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 YARNIFY. Made with 💖 | All Rights Reserved</p>
        </div>
    </footer>


    <script src="assets/js/main.js"></script>
</body>
</html>
